﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ClassroomProject.Models
{
    public class Teacher
    {
        public int Id { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }      
        [Required]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Not a valid contact number.")]
        public string ContactNo { get; set; }
        [Required]
        public string EmailAddress { get; set; }

        public ICollection<TeacherSubject> Subjects { get; set; } = new List<TeacherSubject>();
        public ICollection<TeacherClassroom> Classrooms { get; set; } = new List<TeacherClassroom>();
    }
}
