﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ClassroomProject.Models
{
    public class Student
    {
        public int Id { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string ContactPerson { get; set; }
        [Required]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Not a valid contact number.")]
        public string ContactNo { get; set; }
        [Required]
        public string EmailAddress { get; set; }
        [Required]
        public DateTime DateOfBirth { get; set; }
        public int Age { get; set; }
        public Classroom Classroom { get; set; }
        [Required]
        public int ClassroomId { get; set; }
    }
}
