﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ClassroomProject.Models
{
    public class Classroom
    {
        public int Id { get; set; }

        [Required]
        public string ClassroomName { get; set; }

        public ICollection<TeacherClassroom> Teachers { get; set; }
    }
}
