namespace ClassroomProject.DTOs
{
    public class SubjectDto
    {
        public int Id { get; set; }
        public string SubjectName { get; set; }
    }
}