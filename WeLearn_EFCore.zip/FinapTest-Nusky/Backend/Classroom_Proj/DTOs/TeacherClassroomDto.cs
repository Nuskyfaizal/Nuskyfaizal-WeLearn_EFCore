namespace ClassroomProject.DTOs
{
    public class TeacherClassroomDto
    {
        public int Id { get; set; }
        public string ClassroomName { get; set; }
    }
}