﻿using ClassroomProject.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassroomProject.Data
{
    public class Seed
    {
        public static async Task SeedData(DataContext _context)
        {
            if (!_context.Classrooms.Any())
            {
                var classrooms = new List<Classroom>
                {
                    new Classroom
                    {
                        ClassroomName = "Grade 6A"
                    },
                    new Classroom
                    {
                        ClassroomName = "Grade 10A"
                    }
                };

                await _context.Classrooms.AddRangeAsync(classrooms);
                await _context.SaveChangesAsync();
            }
        }
    }
}
