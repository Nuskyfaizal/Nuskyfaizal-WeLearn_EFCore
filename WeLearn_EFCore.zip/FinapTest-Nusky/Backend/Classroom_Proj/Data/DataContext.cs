﻿using ClassroomProject.Models;
using Microsoft.EntityFrameworkCore;

namespace ClassroomProject.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<Student> Students { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Classroom> Classrooms { get; set; }
        public DbSet<TeacherSubject> TeacherSubjects {get; set;}
        public DbSet<TeacherClassroom> TeacherClassrooms {get; set;}

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<TeacherSubject>().HasKey(k => new { k.TeacherId, k.SubjectId });

            builder.Entity<TeacherSubject>()
                .HasOne(x => x.Teacher)
                .WithMany(s => s.Subjects)
                .HasForeignKey(k => k.TeacherId);

            builder.Entity<TeacherSubject>()
                .HasOne(s => s.Subject)
                .WithMany(t => t.Teachers)
                .HasForeignKey(k => k.SubjectId);

            builder.Entity<TeacherClassroom>().HasKey(k => new { k.TeacherId, k.ClassroomId });

            builder.Entity<TeacherClassroom>()
                .HasOne(x => x.Teacher)
                .WithMany(s => s.Classrooms)
                .HasForeignKey(k => k.TeacherId);

            builder.Entity<TeacherClassroom>()
                .HasOne(s => s.Classroom)
                .WithMany(t => t.Teachers)
                .HasForeignKey(k => k.ClassroomId);
        }
    }

    
}
