﻿using ClassroomProject.Models;
using ClassroomProject.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace ClassroomProject.Controllers
{
    [Route("api/[controller]")]
    public class SubjectController : Controller
    {
        private readonly ISubjectRepository _subjectRepo;

        public SubjectController(ISubjectRepository subjectRepo)
        {
            _subjectRepo = subjectRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetSubjectList()
        {
            var subjects = await _subjectRepo.GetSubjects();

            if (subjects.Count() == 0) return NotFound("No data to show");

            return Ok(subjects);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetSubjectDetail(int id)
        {
            var getSubject = await _subjectRepo.GetSubject(id);

            if (getSubject == null) return NotFound("No data to show");

            return Ok(getSubject);
        }

        [HttpPost]
        public async Task<ActionResult> CreateSubject([FromBody] Subject subject)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var isSubjectCreated = await _subjectRepo.AddSubject(subject);

            if (!isSubjectCreated) return BadRequest("Failed to add subject");

            return Ok("subject created successfully");
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteSubject(int id)
        {
            var deleteSubject = await _subjectRepo.DeleteSubject(id);

            if(!deleteSubject) return BadRequest("Failed to delete subject");

            return Ok("Subject deleted successfully");
        }
    }
}
