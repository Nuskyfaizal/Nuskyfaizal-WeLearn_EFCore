﻿using ClassroomProject.Data;
using ClassroomProject.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
   public class ClassroomRepository: IClassroomRepository
   {
        private readonly DataContext _context;

        public ClassroomRepository(DataContext context)
        {
            _context = context;
        }
        public async Task<bool> AddClassroom(Classroom classroom)
        {
            _context.Classrooms.Add(classroom);

            var result = await _context.SaveChangesAsync() > 0;

            if (!result) return false;

            return true;
        }

        public async Task<Classroom> GetClassroom(int id)
        {
            return await _context.Classrooms.FindAsync(id);
        }

        public async Task<List<Classroom>> GetClassrooms()
        {
            return await _context.Classrooms.ToListAsync();
        }

        public async Task<bool> DeleteClassroom(int id)
        {
            var classroom = await _context.Classrooms.FindAsync(id);

            _context.Remove(classroom);

            var result = await _context.SaveChangesAsync() > 0;

            if(result) return true;

            return false;
        }
   }
}
