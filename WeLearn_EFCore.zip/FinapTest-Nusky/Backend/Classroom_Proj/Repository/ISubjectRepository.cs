﻿using ClassroomProject.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public interface ISubjectRepository
    {
        Task<bool> AddSubject(Subject subject);
        Task<List<Subject>> GetSubjects();
        Task<Subject> GetSubject(int id);
        Task<bool> DeleteSubject(int id);
    }
}
