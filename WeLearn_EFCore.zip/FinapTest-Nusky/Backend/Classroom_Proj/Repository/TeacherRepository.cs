﻿using ClassroomProject.Data;
using ClassroomProject.DTOs;
using ClassroomProject.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public class TeacherRepository : ITeacherRepository
    {
        private readonly DataContext _context;

        public TeacherRepository(DataContext context)
        {
            _context = context;
        }

        public async Task<bool> AddTeacher(Teacher teacher)
        {
            _context.Teachers.Add(teacher);

            var result = await _context.SaveChangesAsync() > 0;

            if (!result) return false;

            return true;
        }

        public async Task<Teacher> GetTeacher(int id)
        {
            return await _context.Teachers.FindAsync(id);
        }

        public async Task<List<Teacher>> GetTeachers()
        {
            return await _context.Teachers.ToListAsync();
        }

        public async Task<bool> DeleteTeacher(int id)
        {
            var teacher = await _context.Teachers.FindAsync(id);

            _context.Remove(teacher);

            var result = await _context.SaveChangesAsync() > 0;

            if (result) return true;

            return false;
        }

        public async Task<bool> EditTeacher(Teacher teacherForEdit, int id)
        {
            var teacherReturned = await _context.Teachers.FindAsync(id);

            teacherReturned.EmailAddress = teacherForEdit.EmailAddress;
            teacherReturned.ContactNo = teacherForEdit.ContactNo;

            var result = await _context.SaveChangesAsync() > 0;

            if (result) return true;

            return false;
        }

        //CHECK FOR THE EXISTING DATA AND UPDATE OR REMOVE ACCORDINGLY
        public async Task<bool> AllocateSubject(List<SubjectDto> subjects, int id)
        {
            var existingIdsForTeacherId = await _context.TeacherSubjects
               .Where(t => t.TeacherId == id)
               .ToListAsync();

            foreach (var subject in subjects)
            {
                var existingTeacherIdSubjectId = existingIdsForTeacherId
                    .FirstOrDefault(t => t.SubjectId == subject.Id);

                if (existingTeacherIdSubjectId != null)
                {
                    if (existingTeacherIdSubjectId.SubjectId != subject.Id)
                    {
                        existingTeacherIdSubjectId.SubjectId = subject.Id;
                        _context.TeacherSubjects.Update(existingTeacherIdSubjectId);
                    }

                    existingIdsForTeacherId.Remove(existingTeacherIdSubjectId);
                }
                else
                {
                    var newTeacherSubject = new TeacherSubject
                    {
                        SubjectId = subject.Id,
                        TeacherId = id
                    };
                    _context.TeacherSubjects.Add(newTeacherSubject);
                }
            }
            _context.TeacherSubjects.RemoveRange(existingIdsForTeacherId);

            var result = await _context.SaveChangesAsync() > 0;
            return result;
        }

        public async Task<List<Subject>> GetTeacherSubjectDetails(int id)
        {
            var subjects = await _context.TeacherSubjects
                .Where(x => x.TeacherId == id)
                .Select(s => s.Subject)
                .ToListAsync();

            return subjects;
        }

        public async Task<bool> AllocateClassroom(List<TeacherClassroomDto> classrooms, int id)
        {
            var existingIdsForTeacherId = await _context.TeacherClassrooms
               .Where(t => t.TeacherId == id)
               .ToListAsync();

            foreach (var classroom in classrooms)
            {
                var existingTeacherIdClassroomId = existingIdsForTeacherId
                    .FirstOrDefault(t => t.ClassroomId == classroom.Id);

                if (existingTeacherIdClassroomId != null)
                {
                    if (existingTeacherIdClassroomId.ClassroomId != classroom.Id)
                    {
                        existingTeacherIdClassroomId.ClassroomId = classroom.Id;
                        _context.TeacherClassrooms.Update(existingTeacherIdClassroomId);
                    }

                    existingIdsForTeacherId.Remove(existingTeacherIdClassroomId);
                }
                else
                {
                    var newTeacherClassroom = new TeacherClassroom
                    {
                        ClassroomId = classroom.Id,
                        TeacherId = id
                    };
                    _context.TeacherClassrooms.Add(newTeacherClassroom);
                }
            }
            _context.TeacherClassrooms.RemoveRange(existingIdsForTeacherId);

            var result = await _context.SaveChangesAsync() > 0;
            return result;
        }

        public async Task<List<Classroom>> GetTeacherClassroomDetails(int id)
        {
            var classrooms = await _context.TeacherClassrooms
                .Where(x => x.TeacherId == id)
                .Select(s => s.Classroom)
                .ToListAsync();

            return classrooms;
        }
    }
}
