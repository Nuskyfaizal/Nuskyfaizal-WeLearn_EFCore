﻿using ClassroomProject.Data;
using ClassroomProject.DTOs;
using ClassroomProject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly DataContext _context;

        public StudentRepository(DataContext context)
        {
            _context = context;
        }

        public async Task<bool> AddStudent(Student student)
        {
            var studentAge = CalculateAge(student.DateOfBirth);

            var studentClassroom = await _context.Classrooms.FirstOrDefaultAsync(i => i.Id == student.ClassroomId);

            student.Age = studentAge;
            student.Classroom = studentClassroom;

            _context.Students.Add(student);

            var result = await _context.SaveChangesAsync() > 0;

            if (!result) return false;

            return true;
        }

        public async Task<Student> GetStudent(int id)
        {
            return await _context.Students.Include(c => c.Classroom).FirstOrDefaultAsync(s => s.Id == id);
        }

        public async Task<List<Student>> GetStudents()
        {
            return await _context.Students.Include(c => c.Classroom).ToListAsync();
        }

        public async Task<bool> DeleteStudent(int id)
        {
            var student = await _context.Students.FindAsync(id);

            _context.Remove(student);

            var result = await _context.SaveChangesAsync() > 0;

            if (result) return true;

            return false;
        }

        public async Task<bool> EditStudent(Student studentForEdit, int id)
        {
            var studentfromDb = await _context.Students.FindAsync(id);

            studentfromDb.ContactNo = studentForEdit.ContactNo;
            studentfromDb.ContactPerson = studentForEdit.ContactPerson;
            studentfromDb.EmailAddress = studentForEdit.EmailAddress;
            studentfromDb.ClassroomId = studentForEdit.ClassroomId;

            var result = await _context.SaveChangesAsync() > 0;

            if (result) return true;

            return false;
        }

        private int CalculateAge(DateTime dateOfBirth)
        {
            var age = DateTime.Today.Year - dateOfBirth.Year;
            if (dateOfBirth.AddYears(age) > DateTime.Today)
            {
                age--;
            }

            return age;
        }

        public async Task<StudentReportDto> GetStudentReport(int id)
        {
            var student = await _context.Students
                .Include(i => i.Classroom)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (student == null)
            {
                return null;
            }

            var result = new StudentReportDto
            {
                ClassroomName = student.Classroom.ClassroomName,
                ContactNo = student.ContactNo,
                ContactPerson = student.ContactPerson,
                DateOfBirth = student.DateOfBirth,
                EmailAddress = student.EmailAddress
            };

            var teacherIds = await _context.TeacherClassrooms
                .Where(i => i.ClassroomId == student.ClassroomId)
                .Select(i => i.TeacherId).ToListAsync();

            var teachersById = await _context.Teachers
                .Where(i => teacherIds.Contains(i.Id))
                .Select(i => new Teacher { Id = i.Id, FirstName = i.FirstName, LastName = i.LastName })
                .ToDictionaryAsync(i => i.Id);

            var teacherSubjects = await _context.TeacherSubjects
                .Where(i => teacherIds.Contains(i.TeacherId))
                .ToListAsync();

            var subjectIds = teacherSubjects.Select(i => i.SubjectId).ToList();

            var subjectByIds = await _context.Subjects.Where(i => subjectIds.Contains(i.Id)).ToDictionaryAsync(i => i.Id);

            result.SubjectTeachers = new List<SubjectTeacherDto>(teacherSubjects.Count);

            foreach (var teacherSubject in teacherSubjects)
            {
                if(subjectByIds.ContainsKey(teacherSubject.SubjectId) && teachersById.ContainsKey(teacherSubject.TeacherId)){
                    result.SubjectTeachers.Add(new SubjectTeacherDto
                    {
                        SubjectId = teacherSubject.SubjectId,
                        SubjectName = subjectByIds[teacherSubject.SubjectId].SubjectName,
                        TeacherId = teacherSubject.TeacherId,
                        TeacherName = $"{teachersById[teacherSubject.TeacherId].FirstName} {teachersById[teacherSubject.TeacherId].LastName}"
                    }) ;
                }
            }
            return result;
        }
    }
}
