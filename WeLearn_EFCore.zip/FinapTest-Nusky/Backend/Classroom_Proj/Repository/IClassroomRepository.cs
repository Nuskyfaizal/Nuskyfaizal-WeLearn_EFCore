﻿using ClassroomProject.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public interface IClassroomRepository
    {
        Task<bool> AddClassroom(Classroom classroom);
        Task<List<Classroom>> GetClassrooms();
        Task<Classroom> GetClassroom(int id);
        Task<bool> DeleteClassroom(int id);
    }
}
