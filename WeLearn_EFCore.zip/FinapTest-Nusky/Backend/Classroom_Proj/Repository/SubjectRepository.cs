﻿using ClassroomProject.Data;
using ClassroomProject.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public class SubjectRepository : ISubjectRepository
    {
        private readonly DataContext _context;

        public SubjectRepository(DataContext context)
        {
            _context = context;
        }
        public async Task<bool> AddSubject(Subject subject)
        {
            _context.Subjects.Add(subject);

            var result = await _context.SaveChangesAsync() > 0;

            if (!result) return false;

            return true;
        }

        public async Task<Subject> GetSubject(int id)
        {
            return await _context.Subjects.FindAsync(id);
        }

        public async Task<List<Subject>> GetSubjects()
        {
            return await _context.Subjects.ToListAsync();
        }

        public async Task<bool> DeleteSubject(int id)
        {
            var subject = await _context.Subjects.FindAsync(id);

            _context.Remove(subject);

            var result = await _context.SaveChangesAsync() > 0;

            if(result) return true;

            return false;
        }
    }
}
