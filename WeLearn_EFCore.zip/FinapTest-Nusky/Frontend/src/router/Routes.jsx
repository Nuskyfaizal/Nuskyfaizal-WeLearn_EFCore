import App from "../App";
import { createBrowserRouter } from "react-router-dom";
import Student from "../components/Student";
import Teacher from "../components/Teacher";
import Subject from "../components/Subject";
import Classroom from "../components/Classroom";
import AddStudent from "../components/formComponents/AddStudent";
import AddTeacher from "../components/formComponents/AddTeacher";
import AddSubject from "../components/formComponents/AddSubject";
import AddClassroom from "../components/formComponents/AddClassroom";
import TeacherAllocation from "../components/allocationComponent/TeacherAllocation";
import TeacherClassroom from "../components/allocationComponent/TeacherClassroom";
import StudentDetail from "../components/studentDetailReport/StudentDetail";

export const routes = [
    {
        path: '/',
        element: <App />,
        children:[
            {path: 'student', element: <Student />},
            {path: 'addstudent', element: <AddStudent key='create' />},
            {path: 'editstudent/:id', element: <AddStudent key='edit' />},
            {path: 'viewStudentReport', element: <StudentDetail key='edit' />},
            {path: 'teacher', element: <Teacher />},
            {path: 'addteacher', element: <AddTeacher key='create' />},
            {path: 'editteacher/:id', element: <AddTeacher key='edit' />},
            {path: 'manageSubjects', element: <TeacherAllocation/>},
            {path: 'manageClassroom', element: <TeacherClassroom/>},
            {path: 'subject', element: <Subject />},
            {path: 'addsubject', element: <AddSubject />},
            {path: 'classroom', element: <Classroom />},
            {path: 'addclassroom', element: <AddClassroom />},
        ]
    }
]

export const router = createBrowserRouter(routes);