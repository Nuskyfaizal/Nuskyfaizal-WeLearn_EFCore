import axios from "axios";
import { toast } from "react-toastify";

const sleep = (delay) => {
  return new Promise((resolve) => {
    setTimeout(resolve, delay);
  });
};

var url = 'http://localhost:5000/api'

axios.interceptors.response.use(
  async (response) => {
    await sleep(1000);
    return response;
  },
  (error) => {
    const { data, status } = error.response;
    console.log(error.response);
    switch (status) {
      case 400:
        if (typeof data === "string") {
          toast.error(data);
        }
        if (data) {
          const modalStateErrors = [];
          for (const key in data) {
            if (data[key]) {
              modalStateErrors.push(data[key]);
            }
          }
          throw modalStateErrors.flat();
        }
        break;
      case 404:
        toast.error("Not found");
        break;
      case 500:
        toast.error("Server Error");
        break;
      default:
        toast.error("Something went wrong");
        break;
    }
    return Promise.reject(error);
  }
);

const responseBody = (response) => response.data;

const requests = {
  get: (url) => axios.get(url).then(responseBody),
  post: (url, body) => axios.post(url, body).then(responseBody),
  put: (url, body) => axios.put(url, body).then(responseBody),
  del: (url) => axios.delete(url).then(responseBody),
};

const studentUrl = `${url}/student`
const classroomUrl = `${url}/classroom`
const teacherUrl = `${url}/teacher`
const subjectUrl = `${url}/subject`

const Students = {
  list: () => requests.get(studentUrl),
  detail: (id) => requests.get(`${studentUrl}/${id}`),
  create: (student) => requests.post(studentUrl, student),
  del: (id) => requests.del(`${studentUrl}/${id}`),
  edit: (id, updatedStudent) => requests.put(`${studentUrl}/${id}`, updatedStudent),
  reportData: (id) => requests.get(`${studentUrl}/getStudentReport/${id}`)
};

const Teachers = {
  detail: (id) => requests.get(`${teacherUrl}/${id}`),
  list: () => requests.get(teacherUrl),
  create: (teacher) => requests.post(teacherUrl, teacher),
  del: (id) => requests.del(`${teacherUrl}/${id}`),
  edit: (id, updatedTeacher) => requests.put(`${teacherUrl}/${id}`, updatedTeacher),
  allocateSubjects: (id, allocatedSubjects) => requests.post(`${teacherUrl}/allocateSubjects/${id}`, allocatedSubjects),
  getAllocatedSubjects: (id) => requests.get(`${teacherUrl}/allocateSubjects/${id}`),
  allocateClassrooms: (id, allocatedClassrooms) => requests.post(`${teacherUrl}/allocateClassrooms/${id}`, allocatedClassrooms),
  getAllocatedClassrooms: (id) => requests.get(`${teacherUrl}/allocateClassrooms/${id}`)
};

const Classrooms = {
  list: () => requests.get(classroomUrl),
  create: (classroom) => requests.post(classroomUrl, classroom),
  del: (id) => requests.del(`${classroomUrl}/${id}`)
};

const Subjects = {
  list: () => requests.get(subjectUrl),
  create: (subject) => requests.post(subjectUrl, subject),
  del: (id) => requests.del(`${subjectUrl}/${id}`)
};

const agent = {
  Students,
  Teachers,
  Classrooms,
  Subjects
};

export default agent;
