import React, { useEffect, useState } from 'react'
import CommonView from '../app/common/CommonView'
import { useDispatch, useSelector } from 'react-redux';
import { getTeacherData } from '../store/teacherDataSlice';
import LoadingSpinner from '../app/common/LoadingSpinner';

export default function Teacher() {
  const dispatch = useDispatch();
  const { teachersList } = useSelector((state) => state.teacherReducer);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dispatch(getTeacherData()).then((data) => {
      if(data.meta.requestStatus === "fulfilled" || data.meta.requestStatus === "rejected"){
        setLoading(false)
      }
    });
  }, [dispatch]);

  const tableData = teachersList.map((teacher) => ({
    id: teacher.id,
    "First Name": teacher.firstName,
    "Last Name": teacher.lastName,
    "Contact No": teacher.contactNo,
    "Email Address": teacher.emailAddress,
  }));

  return (
    <>
      {loading ? (<LoadingSpinner/>) : (
        <CommonView name="teacher" tableData={tableData} />
      )}    
    </>
  )
}
