import React, { useEffect, useState } from "react";
import CommonView from "../app/common/CommonView";
import { useDispatch, useSelector } from "react-redux";
import { getStudentsData } from "../store/studentDataSlice";
import LoadingSpinner from '../app/common/LoadingSpinner';

export default function Student() {
  const dispatch = useDispatch();
  const { studentsList } = useSelector((state) => state.studentsReducer);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dispatch(getStudentsData()).then((data) => {
      if(data.meta.requestStatus === "fulfilled" || data.meta.requestStatus === "rejected"){
        setLoading(false)
      } 
    });
  }, [dispatch]);

  const tableData = studentsList.map((student) => ({
    id: student.id,
    "First Name": student.firstName,
    "Last Name": student.lastName,
    "Contact Person": student.contactPerson,
    "Contact No": student.contactNo,
    "Email Address": student.emailAddress,
    "Date of Birth": student.dateOfBirth.split('T')[0],
    "Age": student.age,
  }));

  return (
    <>
      {loading ? (<LoadingSpinner/>) : (
        <CommonView name="student" tableData={tableData} />
      )}    
    </>
  );
}
