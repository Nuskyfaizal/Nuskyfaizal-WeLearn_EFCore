import React, { useEffect, useState } from 'react'
import CommonView from '../app/common/CommonView';
import { getClassrooms } from '../store/classroomDataSlice';
import { useDispatch, useSelector } from 'react-redux';
import LoadingSpinner from '../app/common/LoadingSpinner';

export default function Classroom() {
  const dispatch = useDispatch();
  const { classroomList } = useSelector((state) => state.classroomReducer);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dispatch(getClassrooms()).then((data) => {
      if(data.meta.requestStatus === "fulfilled" || data.meta.requestStatus === "rejected"){
        setLoading(false)
      }
    });
  }, [dispatch, classroomList.length]);

  const tableData = classroomList.map((classroom) => ({
    id: classroom.id,
    "Classroom": classroom.classroomName,
  }));

  return (
    <>
      {loading ? (<LoadingSpinner/>) : (
        <CommonView name='classroom' tableData={tableData} />
      )}    
    </>
  )
}
