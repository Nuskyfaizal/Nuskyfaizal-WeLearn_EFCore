import React from 'react'
import TextInput from '../../app/form/TextInput';
import { useForm } from 'react-hook-form';
import FormButtons from '../../app/form/FormButtons';
import Heading from '../../app/common/Heading';
import { useDispatch } from 'react-redux';
import { createSubjects } from '../../store/subjectDataSlice';

export default function AddSubject() {
  const {control, handleSubmit, formState: { isValid}} = useForm({
        mode: 'onTouched'
  });

  const dispatch = useDispatch();

  async function onSubmit(data){
    dispatch(createSubjects(data))         
  }

  return (
    <form className="text-center" onSubmit={handleSubmit(onSubmit)}>
      <Heading title='Subject'/>

      <TextInput label='Subject Name' name='subjectName' control={control} errorM={'Subject Name is required'}/>

      <FormButtons name='subject' isValid={isValid}/>
    </form>
  )
}
