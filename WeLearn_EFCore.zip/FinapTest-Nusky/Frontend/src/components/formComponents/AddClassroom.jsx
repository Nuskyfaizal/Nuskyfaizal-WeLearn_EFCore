import React from "react";
import TextInput from "../../app/form/TextInput";
import { useForm } from "react-hook-form";
import FormButtons from "../../app/form/FormButtons";
import Heading from "../../app/common/Heading";
import { useDispatch } from "react-redux";
import { createClassroom } from "../../store/classroomDataSlice";

export default function AddClassroom() {
  const {
    control,
    handleSubmit,
    formState: { isValid },
  } = useForm({
    mode: "onTouched",
  });

  const dispatch = useDispatch();

  async function onSubmit(data){
    console.log(data)
    dispatch(createClassroom(data))         
  }

  return (
    <form className="text-center" onSubmit={handleSubmit(onSubmit)}>
      <Heading title="Classroom" />

      <TextInput
        label="Classroom Name"
        name="classRoomName"
        control={control}
        errorM={'Classroom Name is required'}
      />

      <FormButtons name="classroom" isValid={isValid} />
    </form>
  );
}
