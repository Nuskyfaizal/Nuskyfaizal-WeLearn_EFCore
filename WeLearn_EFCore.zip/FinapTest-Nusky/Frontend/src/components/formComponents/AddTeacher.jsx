import React, { useEffect, useState } from 'react'
import TextInput from '../../app/form/TextInput';
import { useForm } from 'react-hook-form';
import FormButtons from '../../app/form/FormButtons';
import Heading from '../../app/common/Heading';
import { addTeacher, getTeacher, updateTeacher } from '../../store/teacherDataSlice';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';

export default function AddTeacher() {
  const {control, handleSubmit, setFocus, reset, formState: { isValid}} = useForm({
          mode: 'onTouched'
      });
  const {id} = useParams();
  const dispatch = useDispatch();
  const { teacher } = useSelector((state) => state.teacherReducer);
  const navigate = useNavigate();
  const [editDisabled, setEditDisabled] = useState(false);

  function onSubmit(data){
    try{
      if(id) {
        dispatch(updateTeacher({id: id, updatedTeacher: data})).then(() => {
          navigate(`/teacher`)
        })
      } else{
        dispatch(addTeacher(data)).then(() => {
          navigate(`/teacher`)
        })
      }     
    }catch(error){
      toast.error(error.message)
    }           
  }

  useEffect(() => {
    if(id) {
      dispatch(getTeacher(id)).then(() => {
        const {firstName, lastName, contactNo, emailAddress} = teacher;
        reset({firstName, lastName, contactNo, emailAddress});
        setEditDisabled(true)
      })
    }
    setFocus('firstName')
  },[dispatch, setFocus, id])

  return (
    <form className="text-center" onSubmit={handleSubmit(onSubmit)}>
      <Heading title='Staff'/>

      <TextInput isdisabled={editDisabled} label='First Name' name='firstName' control={control} errorM={'First Name is required'}/>
 
      <TextInput isdisabled={editDisabled} label='Last Name' name='lastName' control={control} errorM={'Last Name is required'}/>

      <TextInput label='Contact Number' name='contactNo' control={control} errorM={'Contact Number is required'}/>

      <TextInput label='Email Address' name='emailAddress' control={control} errorM={'Email Address is required'}/>
            
      <FormButtons name='teacher' isValid={isValid}/>
    </form>  
  )
}
