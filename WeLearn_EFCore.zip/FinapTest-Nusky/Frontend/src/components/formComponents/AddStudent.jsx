import React, { useEffect, useState } from 'react'
import TextInput from '../../app/form/TextInput';
import { useForm } from 'react-hook-form'
import FormButtons from '../../app/form/FormButtons';
import Heading from '../../app/common/Heading';
import Dropdown from '../../app/form/Dropdown';
import { useDispatch, useSelector } from 'react-redux';
import { addStudent, getStudent, updateStudent } from '../../store/studentDataSlice';
import { getClassrooms } from '../../store/classroomDataSlice';
import { toast } from 'react-toastify';
import { useNavigate, useParams } from 'react-router-dom';

export default function AddStudent() {
    const {control, handleSubmit, reset, setFocus, formState: { isValid}} = useForm({mode: 'onTouched'});
    const dispatch = useDispatch();
    const {classroomList} = useSelector(state => state.classroomReducer);
    const {student} = useSelector(state => state.studentsReducer);
    const {id} = useParams();
    const [editDisabled, setEditDisabled] = useState(false);
    const navigate = useNavigate();

    function onSubmit(data){
      try{
        if(id) {
          data.classroomId = parseInt(data.classroomId, 10)
          dispatch(updateStudent({id: id, updatedStudent: data})).then(() => {
            navigate('/student')
          })
        } else{
          data.classroomId = parseInt(data.classroomId, 10)
          dispatch(addStudent(data))
          navigate('/student')
        }
      } catch (error){
        toast.error(error.message)
      }              
    }

    useEffect(() => {
        if(id) {
          dispatch(getStudent(id)).then((res) => {
            if(res.meta.requestStatus === "fulfilled"){
            const dateOfBirth = student.dateOfBirth === undefined || null ? "": student.dateOfBirth.split('T')[0]
            const {firstName, lastName,contactPerson, contactNo, emailAddress,classroomId } = student;
          reset({firstName, lastName,contactPerson, contactNo, emailAddress, dateOfBirth, classroomId});
          setEditDisabled(true)
          }})
        }
        dispatch(getClassrooms()).then((data) => {
          if(data.meta.requestStatus === "rejected"){
            toast.error('Please add classroom before creating a student')
          }
        });
        setFocus('firstName')  
    },[dispatch, setFocus, id])

  return (
    <form className="text-center" onSubmit={handleSubmit(onSubmit)}>
        <Heading title='Student'/>

        <TextInput isdisabled={editDisabled} label='First Name' name='firstName' control={control} errorM={'First Name is required'}/>
 
        <TextInput isdisabled={editDisabled} label='Last Name' name='lastName' control={control} errorM={'Last Name is required'}/>

        <TextInput label='Contact Person' name='contactPerson' control={control} errorM={'Contact Person is required'}/>

        <TextInput label='Contact Number' type='number' name='contactNo' control={control} errorM={'Contact Number is required'}/>

        <TextInput label='Email Address' name='emailAddress' control={control}errorM={'Email Address is required'}/>

        <TextInput isdisabled={editDisabled} label='Date of Birth (YYYY-MM-DD)' type='date' name='dateOfBirth' control={control} errorM={'DOB is required'}/>

        <Dropdown isdisabled={editDisabled} type='select' control={control} name='classroomId' classroomList={classroomList}/>
            
        <FormButtons name='student' isValid={isValid}/>
    </form>
  )
}
