import React, { useEffect, useState } from 'react'
import CommonView from '../app/common/CommonView'
import { useDispatch, useSelector } from 'react-redux';
import { getSubjects } from '../store/subjectDataSlice';
import LoadingSpinner from '../app/common/LoadingSpinner';

export default function Subject() {
  const dispatch = useDispatch();
  const { subjectList } = useSelector((state) => state.subjectReducer);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dispatch(getSubjects()).then((data) => {
      if(data.meta.requestStatus === "fulfilled" || data.meta.requestStatus === "rejected"){
        setLoading(false)
      }
    });   
  }, [dispatch]);

  const tableData = subjectList.map((subject) => ({
    id: subject.id,
    "Subject Name": subject.subjectName,
  }));

  return (
    <>
    {loading ? (<LoadingSpinner/>) : (
      <CommonView name='subject' tableData={tableData}/>
    )}    
    </>   
  )
}
