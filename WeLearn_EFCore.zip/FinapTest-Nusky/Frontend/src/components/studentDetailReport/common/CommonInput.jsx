import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Input, Label } from "reactstrap";
import { getStudentDataForReport, getStudentsData } from "../../../store/studentDataSlice";

export default function CommonInput({ nameLeft, nameRight, type, valueRight, valueLeft }) {
  const { studentsList } = useSelector((state) => state.studentsReducer);
  const dispatch = useDispatch();
  const [studentId, setStudentId] = useState();

  function studentIdToggle(e){
    if(e.target.value !== ""){
      setStudentId(e.target.value)
      dispatch(getStudentDataForReport(e.target.value))
    }
  }

  useEffect(() => {
    dispatch(getStudentsData())
  },[dispatch, valueRight, valueLeft])

  return (
    <div className="d-flex justify-content-around mt-4">
      <div className="d-flex" style={{ width: "300px", height: "50px" }}>
        {type === "select" ? (
          <>
            <Label className="p-2 text-left">{nameLeft}</Label>
            <Input
              onChange={(e) => studentIdToggle(e)}
              value={studentId}
              type={type}
              style={{ width: "200px", height: "38px", marginLeft: "30px" }}
            >
              <option value="">Select a Student</option>
              {studentsList.map((student) => (
                <option key={student.id} value={student.id}>{student.firstName} {student.lastName}</option>
              ))}
            </Input>
          </>
        ) : (
          <div className="d-flex" style={{ width: "300px", height: "50px" }}>
            <Label className="text-left">{nameLeft}</Label>
            <Input
               value={valueLeft}
               onChange={() => {}}
              style={{ width: "200px", height: "38px", marginLeft: "30px" }}
              readOnly
            />
          </div>
        )}
      </div>
      <div className="d-flex" style={{ width: "300px", height: "50px" }}>
        <Label className="text-left">{nameRight}</Label>
        <Input
          value={valueRight}
          onChange={() => {}}
          style={{ width: "200px", height: "38px", marginLeft: "30px" }}
          readOnly
        />
      </div>
    </div>
  );
}
