import React from "react";
import TeacherAndSubject from "./TeacherAndSubject";

import StudentDropDown from "./dropdown/StudentDropDown";

export default function StudentDetail() {
  return (
    <>
      <StudentDropDown/>
      <TeacherAndSubject />
    </>
  );
}
