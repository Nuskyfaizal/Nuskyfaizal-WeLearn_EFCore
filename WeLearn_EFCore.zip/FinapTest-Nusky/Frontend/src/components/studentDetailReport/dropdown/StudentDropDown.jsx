import React from "react";
import { Col} from "reactstrap";
import CommonInput from "../common/CommonInput";
import { useSelector } from "react-redux";

export default function StudentDropDown() {
  const {studentReportData} = useSelector(state => state.studentsReducer)

  return (
    <Col xs="12" className="left-box">
      <div className="box-name">Student Details</div>
        <div className="d-flex align-items-center justify-content-center"></div>
        <CommonInput valueRight={studentReportData.classroomName || ""} nameLeft='Student' nameRight='Classroom' type='select' />
        <CommonInput valueLeft={studentReportData.contactPerson || ""} valueRight={studentReportData.emailAddress || ""} nameLeft='Contact Person' nameRight='Email Address' />
        <CommonInput valueLeft={studentReportData.contactNo || ""} valueRight={studentReportData.dateOfBirth.split('T')[0] || ""} nameLeft='Contact No.' nameRight='Date of Birth' /> 
    </Col>
  );
}
