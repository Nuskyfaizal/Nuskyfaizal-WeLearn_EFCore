import React, { useEffect, useState } from "react";
import {Container,Row,Col,Label,Button,Input,Table} from "reactstrap";
import "./TeacherAllocation.scss";
import TeacherDetailsDropdown from "./TeacherDetailsDropdown";
import { useLocation, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from "react-redux";
import { getSubjects } from "../../store/subjectDataSlice";

export default function TeacherAllocation() {
 const location = useLocation();
 const navigate = useNavigate();
 const dispatch = useDispatch();
 const { subjectList } = useSelector(state => state.subjectReducer);
 const { allocatedSubjectList } = useSelector((state) => state.teacherReducer);
 const [isTeacherSelected, setIsTeacherSelected] = useState(false);
 const [isSubjectSelected, setisSubjectSelected] = useState(false);
 const [allocatedSubjects, setAllocatedSubjects] = useState([]);
 const [selectedSubjectId, setSelectedSubjectId] = useState();

 function subjectSelectToggle(e){
  if(e.target.value !== "")
  setSelectedSubjectId(e.target.value)
  setisSubjectSelected(true)
 }

 function allocateSubject() {
  const subject = subjectList.find(subject => subject.id == selectedSubjectId);
  if(subject && !allocatedSubjects.some(allocated => allocated.id === subject.id)){
    setAllocatedSubjects([...allocatedSubjects, {id: subject.id, subjectName: subject.subjectName}])
  }
 }

 function onDeallocate(id){
  setAllocatedSubjects(allocatedSubjects.filter(subject => subject.id !== id))
 }

  useEffect(() => {
    dispatch(getSubjects())
    if(isTeacherSelected){
      setAllocatedSubjects(allocatedSubjectList)
    }
  },[dispatch,isTeacherSelected, allocatedSubjectList])

  return (
    <Container>
      <div className="d-flex justify-content-end mb-4">
        <Button color="primary" className="ml-auto" onClick={() => navigate('/manageClassroom')}>
          {location.pathname === '/manageSubjects' ? 'Manage Classrooms' : 'Manage Subjects'}       
        </Button>
      </div>
      <Row>
        <TeacherDetailsDropdown setIsTeacherSelected={setIsTeacherSelected} allocatedSubjectOrClassroom={allocatedSubjects} />

          <Col xs="12" className="right-box">
            <div className="box-name">Allocate Subjects</div>
              <div className="d-flex justify-content align-items-center">
                <Label className="p-4 mr-1">Subject</Label>
                <Input
                  onChange={(e) => subjectSelectToggle(e)}
                  value={selectedSubjectId}
                  type="select"
                  style={{ width: "200px", height: "38px", marginRight: "30px" }}
                >
                  <option value=''>Select a Subject</option>
                  {subjectList.map((subject) => (
                    <option key={subject.id} value={subject.id}>{subject.subjectName}</option>
                  ))}
                </Input>
                <Button color="primary" disabled={!isSubjectSelected && !isTeacherSelected} onClick={allocateSubject}>
                  Allocate
                </Button>
              </div>
         
            {allocatedSubjects.length >= 1 && (
              <div className="grid">
                <Table bordered>
              <thead>
                <tr className="table-secondary">
                  <th>Subjects</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody className="table-secondary">
                {allocatedSubjects.map((subject, index) => (
                  <tr key={index}>
                    <td>{subject.subjectName}</td>
                    <td width={3}>
                      <Button color="primary" onClick={() => onDeallocate(subject.id)}>Deallocate</Button>
                    </td>
                  </tr>
                ))} 
              </tbody>
            </Table>
          </div>
            )}
            
        </Col>
      </Row>
    </Container>
  );
}
