import { useLocation, Outlet, useNavigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import HomePage from "./components/HomePage";
import NavBar from "./components/NavBar";
import { Container } from "reactstrap";
import {IoArrowBackCircle} from 'react-icons/io5'

function App() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <>
      <ToastContainer position="bottom-right" hideProgressBar theme="colored" />
      <NavBar />
      {location.pathname === "/" ? (
        <HomePage />
      ) : (
        <>
          <Container style={{ marginTop: "4em" }}>           
            <div>
              <IoArrowBackCircle
                size={40}
                color="blue"
                onClick={() => navigate(-1)}
                cursor="pointer"
              />
            </div>
            <Outlet />
          </Container>
        </>
      )}
    </>
  );
}

export default App;
