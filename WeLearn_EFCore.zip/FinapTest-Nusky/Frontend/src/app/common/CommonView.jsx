import React from "react";
import CommonTable from "./CommonTable";
import { Link } from "react-router-dom";
import { Container } from "reactstrap";

export default function CommonView({ name, tableData }) {

  return (
    <>
      <Container className="d-flex justify-content-between align-items-center mt-1 mr-4">
        <div></div>
        <div className="d-flex">
          {(name === 'teacher') && (
            <Link to={`/manageSubjects`} className="btn btn-primary" style={{ marginRight: '20px' }}>
              Manage Allocations
            </Link>
          )}
          {(name === 'student') && (
            <Link to={`/viewStudentReport`} className="btn btn-primary" style={{ marginRight: '20px' }}>
              View Student Report
            </Link>
          )}
          <Link to={`/add${name}`} className="btn btn-primary">
            Add {name}
          </Link>
        </div>
    </Container>
      {tableData.length > 0 ? (
        <div>
          <CommonTable data={tableData} name={name} />
        </div>
      ) : (
        <div className="text-center mt-5">
          <h3>OOPs no {name} data to show, please click Add button to add {name}{" "}details </h3>
        </div>
      )}
    </>
  );
}
