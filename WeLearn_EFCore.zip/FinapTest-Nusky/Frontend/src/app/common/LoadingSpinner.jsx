import React from "react";
import { Spinner } from "reactstrap";

export default function LoadingSpinner() {
  return (
    <Spinner className="m-5 text-center" color="primary" style={{ position: "fixed", top: "50%", left: "50%"}}> 
      Loading...
    </Spinner>
  );
}
