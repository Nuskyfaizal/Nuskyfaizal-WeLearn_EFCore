import React from 'react'

export default function Heading({title}) {
  return (
        <h2>Add {title} Details Here</h2>   
  )
}
