import React, { useState } from "react";
import { Container, Table } from "reactstrap";
import { FiEdit } from "react-icons/fi";
import { RiDeleteBin2Line } from "react-icons/ri";
import { MdOutlineViewHeadline } from "react-icons/md";
import { useDispatch } from "react-redux";
import { deleteClassroom } from "../../store/classroomDataSlice";
import { deleteStudent } from "../../store/studentDataSlice";
import { deleteSubject } from "../../store/subjectDataSlice";
import { deleteTeacher } from "../../store/teacherDataSlice";
import { useNavigate } from "react-router-dom";

export default function CommonTable({ data, name }) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [tableData, setTableData] = useState(data);

  function tableFilter(id){
    const afterDeletion = tableData.filter(row => row.id !== id)
    return setTableData(afterDeletion)
  }

  function editHandler(id) {
    navigate(`/edit${name}/${id}`)
  }

  function deleteHandler(id) {
    switch (name) {
      case 'classroom':
        dispatch(deleteClassroom(id)).then(() => {
          tableFilter(id)
        })
        break;
      case 'student':
        dispatch(deleteStudent(id)).then(() => {
          tableFilter(id)
        })
        break;
      case 'subject':
        dispatch(deleteSubject(id)).then(() => {
          tableFilter(id)
        })
        break;
      case 'teacher':
        dispatch(deleteTeacher(id)).then(() => {
          tableFilter(id)
        })
        break;
      default:
        break;
    }
  }

  return (
    <Container className="text-center mt-5">
      <Table striped>
        <thead>
          <tr>
            {Object.keys(tableData[0])
              .filter((header) => header !== "id")
              .map((header, index) => (
                <th key={index}>{header}</th>
            ))}
            {(name === 'student' || name === 'teacher') && (
              <>
                <th>Edit</th>
              </> 
            )}
            
            <th>Delete</th>           
          </tr>
        </thead>
        <tbody>
          {tableData.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {Object.entries(row).map(([key, value], cellIndex) =>
                key !== "id" ? <td key={cellIndex}>{value}</td> : null
              )}
              {(name === 'student' || name === 'teacher') && (
                <td><FiEdit size={25} color="blue" cursor="pointer" onClick={() => editHandler(row.id)}/></td>
              )} 
              <td><RiDeleteBin2Line size={25} color="red" cursor="pointer" onClick={() => deleteHandler(row.id)} /></td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
}
