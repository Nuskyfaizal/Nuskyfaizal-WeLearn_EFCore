import React from "react";
import { Button } from "reactstrap";
import {  useNavigate } from 'react-router';

export default function FormButtons({isValid, name}) {
  const navigate = useNavigate();

  const doReturn = () => {
    navigate(`/${name}`)
  }
  
  return (
    <div className="form-group d-flex justify-content-between mt-3">
      <div>
        <Button onClick={doReturn} color="danger">Cancel</Button>
      </div>
      <div>
        <Button disabled={!isValid} color="primary">Submit</Button>
      </div>
    </div>
  );
}
