import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import agent from "../api/agent";
import { toast } from "react-toastify";

const initialState = {
  teachersList: [],
  teacher: [],
  allocatedSubjectList: [],
  allocatedClassroomList: []
};

const teacherDataSlice = createSlice({
  name: "teacherData",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getTeacherData.fulfilled, (state, action) => {
        state.teachersList = action.payload;
      })
      .addCase(getTeacher.fulfilled, (state, action) => {
        state.teacher = action.payload;
      })
      .addCase(getAllocatedSubjects.fulfilled, (state, action) => {
        state.allocatedSubjectList = action.payload
      })
      .addCase(getAllocatedClassrooms.fulfilled, (state, action) => {
        state.allocatedClassroomList = action.payload
      })
  },
});

export default teacherDataSlice.reducer;

export const getTeacherData = createAsyncThunk(
  "teacherData/getTeachers",
  async () => {
    const teacherList = await agent.Teachers.list();
    return teacherList;
  }
);

export const getTeacher = createAsyncThunk(
  "teacherData/getTeacher",
  async (id) => {
    const teacher = await agent.Teachers.detail(id);
    return teacher;
  }
);

export const addTeacher = createAsyncThunk(
  "teacherData/add",
  async (createTeacherData, { rejectWithValue }) => {
    try {
      await agent.Teachers.create(createTeacherData);
      toast.success("Teacher Created successfully");
      return createTeacherData;
    } catch (error) {
      toast.error("Please enter valid details");
      return rejectWithValue(error);
    }
  }
);

export const deleteTeacher = createAsyncThunk(
  "teacherData/delete",
  async (id, { rejectWithValue }) => {
    try {
      await agent.Teachers.del(id);
      toast.success("Teacher information deleted successfully");
      return "ok";
    } catch (error) {
      toast.error("Error while deleting teacher infromation");
      return rejectWithValue(error);
    }
  }
);

export const updateTeacher = createAsyncThunk(
  "teacherData/update",
  async ({id, updatedTeacher}) => {
    try {
      await agent.Teachers.edit(id, updatedTeacher);
      toast.success("Teacher updated successfully");
      return "ok";
    } catch (error) {
      toast.error("Error while updating teacher");
      return 'failed';
    }
  }
);

export const allocateSubject = createAsyncThunk("teacherData/allocateSubject", 
  async ({id, allocatedSubject}) => {
    try {
      await agent.Teachers.allocateSubjects(id,allocatedSubject)
      toast.success("Updated records successfully");
      return "ok";
    } catch (error) {
      console.log(error);
    }
})

export const getAllocatedSubjects = createAsyncThunk(
  "teacherData/getAllocatedSubjects",
  async (id) => {
    const allocatedSubjectList = await agent.Teachers.getAllocatedSubjects(id);
    return allocatedSubjectList;
  }
);

export const allocateClassroom = createAsyncThunk("teacherData/allocateClassroom", 
  async ({id, allocatedClassroom}) => {
    console.log(id, allocatedClassroom)
    try {
      await agent.Teachers.allocateClassrooms(id,allocatedClassroom)
      toast.success("Updated records successfully");
      return "ok";
    } catch (error) {
      console.log(error);
    }
})

export const getAllocatedClassrooms = createAsyncThunk(
  "teacherData/getAllocatedClassrooms",
  async (id) => {
    const allocatedClassroomList = await agent.Teachers.getAllocatedClassrooms(id);
    return allocatedClassroomList;
  }
);
