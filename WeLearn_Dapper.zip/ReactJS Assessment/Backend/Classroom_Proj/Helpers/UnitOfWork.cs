using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Classroom_Proj.Database;
using Dapper;

namespace Classroom_Proj.Helpers
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IDbConnectionFactory _connectionFactory;

        public UnitOfWork(IDbConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<bool> DeleteAsync<T>(int id)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            var result = await connection.ExecuteAsync(
                $"DELETE FROM {typeof(T).Name} WHERE Id = @Id", new { Id = id });

            return result > 0;
        }

        public async Task<IEnumerable<T>> GetAllAsync<T>()
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            return await connection.QueryAsync<T>("SELECT * FROM " + typeof(T).Name);
        }

        public async Task<T> GetAsync<T>(int id)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            return await connection.QuerySingleOrDefaultAsync<T>(
                $"SELECT * FROM {typeof(T).Name} WHERE Id = @Id", new { Id = id });
        }

        public async Task<IEnumerable<T>> QueryBySP<T>(string storedProcedureName, 
            Dictionary<string, Tuple<string, DbType, ParameterDirection>> parameters)
        {
            try
            {
                DynamicParameters dynamicParameters = new DynamicParameters();

                foreach (KeyValuePair<string, Tuple<string, DbType, ParameterDirection>> entry in parameters)
                {
                    if (entry.Value.Item2 == DbType.Guid)
                    {
                        Guid guid = new Guid(entry.Value.Item1);
                        dynamicParameters.Add(entry.Key, guid, DbType.Guid, entry.Value.Item3);
                    }
                    else
                    {
                        dynamicParameters.Add(entry.Key, entry.Value.Item1, entry.Value.Item2, entry.Value.Item3);
                    }
                }

                using var connection = await _connectionFactory.CreateConnectionAsync();

                IEnumerable<T> result = connection.Query<T>(
                    storedProcedureName,
                    param: dynamicParameters,
                    commandType: CommandType.StoredProcedure);

                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<int> ExecuteSP(string storedProcedureName, 
            Dictionary<string, Tuple<string, DbType, ParameterDirection>> parameters)
        {
            DynamicParameters dynamicParameters = new DynamicParameters();
            DbType outputType;
            string outputName = "";

            foreach (KeyValuePair<string, Tuple<string, DbType, ParameterDirection>> entry in parameters)
            {
                if (entry.Value.Item2 == DbType.Guid)
                {
                    Guid guid = new Guid(entry.Value.Item1);
                    dynamicParameters.Add(entry.Key, guid, DbType.Guid, entry.Value.Item3);
                }
                else
                {
                    dynamicParameters.Add(entry.Key, entry.Value.Item1, entry.Value.Item2, entry.Value.Item3);
                }

                if (entry.Value.Item3 == ParameterDirection.Output || entry.Value.Item3 == ParameterDirection.InputOutput)
                {
                    outputType = entry.Value.Item2;
                    outputName = entry.Key;
                }
            }
            try
            {
                using var connection = await _connectionFactory.CreateConnectionAsync();

                object result = (await connection.QueryAsync(
                    storedProcedureName,
                    param: dynamicParameters,
                    commandType: CommandType.StoredProcedure)).FirstOrDefault();

                return dynamicParameters.Get<int>(outputName);
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}