using ClassroomProject.Models;
using FluentValidation;

namespace Classroom_Proj.Validations
{
    public class SubjectRequestValidator: AbstractValidator<Subject>
    {
        public SubjectRequestValidator()
        {
            RuleFor(x => x.SubjectName).NotEmpty();
        }    
    }
}