using ClassroomProject.Models;
using FluentValidation;

namespace Classroom_Proj.Validations
{
    public class TeacherRequestValidator: AbstractValidator<Teacher>
    {
        public TeacherRequestValidator()
        {
            RuleFor(x => x.FirstName).NotEmpty();
            RuleFor(x => x.LastName).NotEmpty();
            RuleFor(x => x.ContactNo).NotEmpty().Length(10).WithMessage("Contact number must be 10 digits.");;
            RuleFor(x => x.EmailAddress).NotEmpty().EmailAddress();
        }
    }
}