using ClassroomProject.Models;
using FluentValidation;

namespace Classroom_Proj.Validations
{
    public class ClassroomRequestValidator: AbstractValidator<Classroom>
    {
        public ClassroomRequestValidator()
        {
            RuleFor(x => x.ClassroomName).NotEmpty();
        }
    }
}