﻿using ClassroomProject.Models;
using ClassroomProject.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace ClassroomProject.Controllers
{
    [Route("api/[controller]")]
    public class StudentController : Controller
    {
        private readonly IStudentRepository _studentRepo;

        public StudentController(IStudentRepository studentRepo)
        {
            _studentRepo = studentRepo;
        }
        [HttpGet]
        public async Task<IActionResult> GetStudentList()
        {
            var students = await _studentRepo.GetStudents();

            if (students.Count() == 0) return NotFound("No data to show");

            return Ok(students);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetStudentDetail(int id)
        {
            var getTeacher = await _studentRepo.GetStudent(id);

            if (getTeacher == null) return NotFound("No data to show");

            return Ok(getTeacher);
        }

        [HttpPost]
        public async Task<IActionResult> CreateStudent([FromBody] Student student)
        {
            var isstudentCreated = await _studentRepo.AddStudent(student);

            if (!isstudentCreated) return BadRequest("Failed to add student");

            return Ok("student created successfully");
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteStudent(int id)
        {
            var deleteStudent = await _studentRepo.DeleteStudent(id);

            if(!deleteStudent) return BadRequest();

            return Ok("Student deleted successfully");
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> EditStudent([FromBody] Student studentForEdit, int id)
        {
            var editStudent = await _studentRepo.EditStudent(studentForEdit, id);

            if(!editStudent) return BadRequest("Failed to delete student");

            return Ok("Student deleted successfully");
        }

        [HttpGet("getStudentReport/{id}")]
        public async Task<ActionResult> GetStudentReport(int id)
        {
            var studentDetail = await _studentRepo.GetStudentReport(id);

            if(studentDetail != null) return Ok(studentDetail);

            return BadRequest("Error while fetching data");           
        }
    }
}
