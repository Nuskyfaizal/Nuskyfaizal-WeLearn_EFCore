﻿using ClassroomProject.Models;
using ClassroomProject.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace ClassroomProject.Controllers
{
    [Route("api/[controller]")]
    public class ClassroomController : Controller
    {
        private readonly IClassroomRepository _classroomRepo;

        public ClassroomController(IClassroomRepository classroomRepo )
        {
            _classroomRepo = classroomRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetClassroomList()
        {
            var classrooms = await _classroomRepo.GetClassrooms();

            if (classrooms.Count() == 0) return NotFound("No data to show");

            return Ok(classrooms);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetClassroomDetail(int id)
        {
            var getClassroom = await _classroomRepo.GetClassroom(id);

            if (getClassroom == null) return NotFound("No data to show");

            return Ok(getClassroom);
        }

        [HttpPost]
        public async Task<ActionResult> CreateClassroom([FromBody] Classroom classroom)
        {
            var isClassroomCreated = await _classroomRepo.AddClassroom(classroom);

            if(!isClassroomCreated) return BadRequest("Cannot add the same classroom");

            return Ok("Classroom created successfully");
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteClassroom(int id)
        {
            var deleteClassroom = await _classroomRepo.DeleteClassroom(id);

            if(!deleteClassroom) 
                return BadRequest("Unable to delete classroom. Please make sure classroom is not allocated to a teacher or student");

            return Ok("Classroom deleted successfully");
        }
    }
}
