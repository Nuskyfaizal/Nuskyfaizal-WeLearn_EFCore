﻿using ClassroomProject.DTOs;
using ClassroomProject.Models;
using ClassroomProject.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassroomProject.Controllers
{
    [Route("api/[controller]")]
    public class TeacherController : Controller
    {
        private readonly ITeacherRepository _teacherRepo;

        public TeacherController(ITeacherRepository teacherRepo)
        {
            _teacherRepo = teacherRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetTeacherList()
        {
            var teachers = await _teacherRepo.GetTeachers();

            if (teachers.Count() == 0) return NotFound("No data to show");

            return Ok(teachers);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetTeacherDetail(int id)
        {
            var getTeacher = await _teacherRepo.GetTeacher(id);

            if (getTeacher == null) return NotFound("No data to show");

            return Ok(getTeacher);
        }

        [HttpPost]
        public async Task<IActionResult> CreateTeacher([FromBody] Teacher teacher)
        {
            var isTeacherCreated = await _teacherRepo.AddTeacher(teacher);

            if (!isTeacherCreated) return BadRequest("Failed to add teacher");

            return Ok("teacher created successfully");
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteClassroom(int id)
        {
            var deleteTeacher = await _teacherRepo.DeleteTeacher(id);

            if(!deleteTeacher) return BadRequest("Failed to delete teacher");

            return Ok("Teacher deleted successfully");
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> EditTeacher([FromBody] Teacher teacherforEdit, int id)
        {
            var isTeacherUpdated = await _teacherRepo.EditTeacher(teacherforEdit, id);

            if (!isTeacherUpdated) return BadRequest("Failed to update teacher");

            return Ok("teacher updated successfully");
        }

        [HttpPost("allocateSubjects/{id}")]
        public async Task<IActionResult> AllocateSubjects([FromBody] List<SubjectDto> subjects, int id)
        {          
            var result = await _teacherRepo.AllocateSubject(subjects, id);
            
            if(result) return Ok();

            return BadRequest("Data already exists");
        }

        [HttpGet("allocateSubjects/{id}")]
        public async Task<IActionResult> GetTeacherSubjectDetails(int id)
        {
            var result = await _teacherRepo.GetTeacherSubjectDetails(id);

            return Ok(result);
        }

        [HttpPost("allocateClassrooms/{id}")]
        public async Task<IActionResult> AllocateClassroom([FromBody] List<TeacherClassroomDto> classrooms, int id)
        {          
            var result = await _teacherRepo.AllocateClassroom(classrooms, id);
            
            if(result) return Ok();

            return BadRequest("Data already exists");
        }

        [HttpGet("allocateClassrooms/{id}")]
        public async Task<IActionResult> GetTeacherClassroomDetails(int id)
        {
            var result = await _teacherRepo.GetTeacherClassroomDetails(id);

            return Ok(result);
        }
    }
}
