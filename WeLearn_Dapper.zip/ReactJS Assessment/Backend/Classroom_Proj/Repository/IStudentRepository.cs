﻿using ClassroomProject.DTOs;
using ClassroomProject.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public interface IStudentRepository
    {
        Task<bool> AddStudent(Student student);
        Task<IEnumerable<Student>> GetStudents();
        Task<Student> GetStudent(int id);
        Task<bool> DeleteStudent(int id);
        Task<bool> EditStudent(Student studentForEdit, int id);
        Task<StudentReportDto> GetStudentReport(int id);
    }
}
