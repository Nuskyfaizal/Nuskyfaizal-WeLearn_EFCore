﻿using Classroom_Proj.Database;
using Classroom_Proj.Helpers;
using ClassroomProject.DTOs;
using ClassroomProject.Models;
using Dapper;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly IDbConnectionFactory _connectionFactory;
        private readonly IUnitOfWork _unitOfWork;

        public StudentRepository(IDbConnectionFactory connectionFactory, IUnitOfWork unitOfWork)
        {
            _connectionFactory = connectionFactory;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> AddStudent(Student student)
        {
            var studentAge = CalculateAge(student.DateOfBirth);
            student.Age = studentAge;

           using var connection = await _connectionFactory.CreateConnectionAsync();
            var insertStudent = 
                @"Insert into student (FirstName, LastName, ContactPerson,ContactNo, EmailAddress, DateOfBirth, ClassroomId, Age)
                    Values (@FirstName, @LastName,@ContactPerson, @ContactNo, @EmailAddress, @DateOfBirth, @ClassroomId, @Age)";

            var parameters = new
            {
                student.FirstName,
                student.LastName,
                student.ContactPerson,
                student.ContactNo,
                student.EmailAddress,
                student.DateOfBirth, 
                student.ClassroomId,
                student.Age
            };

            var result = await connection.ExecuteAsync(insertStudent, parameters);

            return result > 0;
        }

        public async Task<Student> GetStudent(int id)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();          

            var student = await connection.QuerySingleOrDefaultAsync<Student>(
                $"SELECT * FROM student WHERE Id = @Id", new { Id = id });

            var studentClassroom = await connection.QuerySingleOrDefaultAsync<Classroom>(
                $"SELECT c.classroomName, c.id FROM classroom c join student s on s.classroomid = c.id WHERE s.Id = @Id", new { Id = id });

            var result = new Student
            {
                Id = student.Id,
                FirstName = student.FirstName,
                LastName = student.LastName,
                ContactNo = student.ContactNo,
                ContactPerson = student.ContactPerson,
                EmailAddress = student.EmailAddress,
                ClassroomId = student.ClassroomId,
                Classroom = new Classroom
                {
                    Id = studentClassroom.Id,
                    ClassroomName = studentClassroom.ClassroomName
                }
            };

            return result;
        }

        public async Task<IEnumerable<Student>> GetStudents()
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();    

            string sql = "SELECT s.*, c.* FROM Student s INNER JOIN Classroom c ON s.ClassroomId = c.Id";
            var studentList = await connection.QueryAsync<Student, Classroom, Student>(
                sql,
                (student, classroom) =>
                {
                    student.Classroom = classroom;
                    return student;
                },
                splitOn: "Id"
            );

            return studentList;
        }

        public async Task<bool> DeleteStudent(int id)
        {
            var isStudentAvailable = await _unitOfWork.GetAsync<Student>(id);

            if (isStudentAvailable == null)
                return false;

            var result = await _unitOfWork.DeleteAsync<Student>(id);

            if (result) return true;

            return false;
        }

        public async Task<bool> EditStudent(Student studentForEdit, int id)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();

            var query = @"UPDATE Teacher SET 
                    FirstName = @FirstName, 
                    LastName = @LastName, 
                    ContactNo = @ContactNo, 
                    EmailAddress = @EmailAddress,
                    ContactPerson = @ContactPerson,
                    ClassroomId = @ClassroomId,
                    DateOfBirth = @DateOfBirth,
                    EmailAddress = @EmailAddress,
                    WHERE 
                    Id = @Id";

            var parameters = new
            {
                Id = id,
                studentForEdit.FirstName,
                studentForEdit.LastName,
                studentForEdit.ContactNo,
                studentForEdit.EmailAddress,
                studentForEdit.ContactPerson,
                studentForEdit.ClassroomId,
                studentForEdit.DateOfBirth
            };

            var result = await connection.ExecuteAsync(query, parameters);
                
            return result > 0;
        }

        private int CalculateAge(DateTime dateOfBirth)
        {
            if(dateOfBirth > DateTime.Now)
                throw new ValidationException("Date of birth cannot be in the future");
            
            var age = DateTime.Today.Year - dateOfBirth.Year;
            if (dateOfBirth.AddYears(age) > DateTime.Today)
            {
                age--;
            }

            return age;
        }

        public Task<StudentReportDto> GetStudentReport(int id)
        {
            throw new NotImplementedException();
        }
    }
}
