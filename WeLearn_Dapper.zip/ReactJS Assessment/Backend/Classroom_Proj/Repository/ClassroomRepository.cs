﻿using Classroom_Proj.Database;
using Classroom_Proj.Helpers;
using ClassroomProject.Models;
using Dapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public class ClassroomRepository : IClassroomRepository
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IDbConnectionFactory _connectionFactory;

        public ClassroomRepository(IUnitOfWork unitOfWork, IDbConnectionFactory connectionFactory)
        {
            _unitOfWork = unitOfWork;
            _connectionFactory = connectionFactory;
        }

        public async Task<bool> AddClassroom(Classroom classroom)
        {
            var isClassroomAvailable = await _unitOfWork.GetAsync<Classroom>(classroom.Id);

            if(isClassroomAvailable == null)
                return false;

            using var connection = await _connectionFactory.CreateConnectionAsync();
            var result = await connection.ExecuteAsync(
                @"INSERT INTO Classroom (ClassroomName) 
                VALUES (@ClassroomName)",
                classroom);
            
            return result > 0;
        }

        public async Task<Classroom> GetClassroom(int id)
        {
            return await _unitOfWork.GetAsync<Classroom>(id);
        }

        public async Task<IEnumerable<Classroom>> GetClassrooms()
        {
            return await _unitOfWork.GetAllAsync<Classroom>();
        }

        public async Task<bool> DeleteClassroom(int id)
        {
            Dictionary<string, Tuple<string, DbType, ParameterDirection>> parameters = 
                new Dictionary<string, Tuple<string, DbType, ParameterDirection>>
            {
                { "p_id", Tuple.Create(id.ToString(), DbType.Int32, ParameterDirection.Input) },
                { "p_result", Tuple.Create(0.ToString(), DbType.Int32, ParameterDirection.InputOutput) }
            };

            var response = await _unitOfWork.ExecuteSP("pr_delete_classroom", parameters);		

            return response > 0;
        }
    }
}
