﻿using Classroom_Proj.Database;
using Classroom_Proj.Helpers;
using ClassroomProject.DTOs;
using ClassroomProject.Models;
using Dapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public class TeacherRepository : ITeacherRepository
    {
        private readonly IDbConnectionFactory _connectionFactory;
        private readonly IUnitOfWork _unitOfWork;

        public TeacherRepository(IDbConnectionFactory connectionFactory, IUnitOfWork unitOfWork)
        {
            _connectionFactory = connectionFactory;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> AddTeacher(Teacher teacher)
        {
            var isTeacherAvailable = await _unitOfWork.GetAsync<Teacher>(teacher.Id);

            if(isTeacherAvailable == null)
                return false;

            using var connection = await _connectionFactory.CreateConnectionAsync();
            var result = await connection.ExecuteAsync(
                @"INSERT INTO Teacher (FirstName, LastName, ContactNo, EmailAddress) 
                VALUES (@FirstName, @LastName, @ContactNo, @EmailAddress)",
                teacher);
            
            return result > 0;
        }

        public async Task<Teacher> GetTeacher(int id)
        {
            return await _unitOfWork.GetAsync<Teacher>(id);
        }

        public async Task<IEnumerable<Teacher>> GetTeachers()
        {
            return await _unitOfWork.GetAllAsync<Teacher>();
        }

        public async Task<bool> DeleteTeacher(int id)
        {
            var isTeacherAvailable = await _unitOfWork.GetAsync<Teacher>(id);

            if(isTeacherAvailable == null)
                return false;

            var result = await _unitOfWork.DeleteAsync<Teacher>(id);

            if (result) return true;

            return false;
        }

        public async Task<bool> EditTeacher(Teacher teacherForEdit, int id)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();

            var query = @"UPDATE Teacher SET 
                    FirstName = @FirstName, 
                    LastName = @LastName, 
                    ContactNo = @ContactNo, 
                    EmailAddress = @EmailAddress 
                WHERE 
                    Id = @Id";

            var parameters = new
            {
                Id = id,
                teacherForEdit.FirstName,
                teacherForEdit.LastName,
                teacherForEdit.ContactNo,
                teacherForEdit.EmailAddress
            };

            var result = await connection.ExecuteAsync(query, parameters);
                
            return result > 0;
        }

        public Task<bool> AllocateSubject(List<SubjectDto> subjects, int id)
        {
            throw new NotImplementedException();
        }

        public Task<List<Subject>> GetTeacherSubjectDetails(int id)
        {
            throw new NotImplementedException();
        }

        public Task<bool> AllocateClassroom(List<TeacherClassroomDto> classrooms, int id)
        {
            throw new NotImplementedException();
        }

        public Task<List<Classroom>> GetTeacherClassroomDetails(int id)
        {
            throw new NotImplementedException();
        }
    }
}
