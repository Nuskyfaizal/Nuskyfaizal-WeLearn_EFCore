﻿using Classroom_Proj.Database;
using Classroom_Proj.Helpers;
using ClassroomProject.Models;
using Dapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public class SubjectRepository : ISubjectRepository
    {
        private readonly IDbConnectionFactory _connectionFactory;
        private readonly IUnitOfWork _unitOfWork;

        public SubjectRepository(IDbConnectionFactory connectionFactory, IUnitOfWork unitOfWork)
        {
            _connectionFactory = connectionFactory;
            _unitOfWork = unitOfWork;
        }
        public async Task<bool> AddSubject(Subject subject)
        {
           var isSubjectAvailable = await _unitOfWork.GetAsync<Subject>(subject.Id);

            if(isSubjectAvailable == null)
                return false;

            using var connection = await _connectionFactory.CreateConnectionAsync();
            var result = await connection.ExecuteAsync(
                @"INSERT INTO Subject (SubjectName) 
                VALUES (@SubjectName)",
                subject);
            
            return result > 0;
        }

        public async Task<Subject> GetSubject(int id)
        {
            return await _unitOfWork.GetAsync<Subject>(id);
        }

        public async Task<IEnumerable<Subject>> GetSubjects()
        {
            return await _unitOfWork.GetAllAsync<Subject>();
        }

        public async Task<bool> DeleteSubject(int id)
        {
            Dictionary<string, Tuple<string, DbType, ParameterDirection>> parameters = 
                new Dictionary<string, Tuple<string, DbType, ParameterDirection>>
            {
                { "p_id", Tuple.Create(id.ToString(), DbType.Int32, ParameterDirection.Input) },
                { "p_result", Tuple.Create(0.ToString(), DbType.Int32, ParameterDirection.InputOutput) }
            };

            var response = await _unitOfWork.ExecuteSP("pr_delete_subject", parameters);		

            return response > 0;       
        }
    }
}
