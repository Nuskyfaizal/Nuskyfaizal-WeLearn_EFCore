﻿using ClassroomProject.DTOs;
using ClassroomProject.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassroomProject.Repository
{
    public interface ITeacherRepository
    {
        Task<bool> AddTeacher(Teacher teacher);
        Task<IEnumerable<Teacher>> GetTeachers();
        Task<Teacher> GetTeacher(int id);
        Task<bool> DeleteTeacher(int id);
        Task<bool> EditTeacher(Teacher teacherForEdit, int id);
        Task<bool> AllocateSubject(List<SubjectDto> subjects, int id);
        Task<List<Subject>> GetTeacherSubjectDetails(int id);
        Task<bool> AllocateClassroom(List<TeacherClassroomDto> classrooms, int id);
        Task<List<Classroom>> GetTeacherClassroomDetails(int id);
    }
}
