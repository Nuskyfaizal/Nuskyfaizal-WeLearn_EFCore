using System.Threading.Tasks;
using Dapper;

namespace Classroom_Proj.Database
{
    public class DataBaseInitializer
    {
        private readonly IDbConnectionFactory _connectionFactory;

        public DataBaseInitializer(IDbConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task InitializeAsync()
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            await connection.ExecuteAsync(@"

                CREATE TABLE IF NOT EXISTS Classroom (
                    Id SERIAL PRIMARY KEY,
                    ClassroomName VARCHAR NOT NULL
                );
                CREATE TABLE IF NOT EXISTS Subject (
                    Id SERIAL PRIMARY KEY,
                    SubjectName VARCHAR NOT NULL
                );

                CREATE TABLE IF NOT EXISTS Teacher (
                    Id SERIAL PRIMARY KEY,
                    FirstName VARCHAR NOT NULL,
                    LastName VARCHAR NOT NULL,
                    ContactNo VARCHAR NOT NULL,
                    EmailAddress VARCHAR NOT NULL
                );

                CREATE TABLE IF NOT EXISTS Student (
                    Id SERIAL PRIMARY KEY,
                    FirstName VARCHAR NOT NULL,
                    LastName VARCHAR NOT NULL,
                    ContactPerson VARCHAR NOT NULL,
                    ContactNo VARCHAR NOT NULL,
                    EmailAddress VARCHAR NOT NULL,
                    DateOfBirth DATE NOT NULL,
                    Age INTEGER NOT NULL,
                    ClassroomId INTEGER NOT NULL,
                    FOREIGN KEY (ClassroomId) REFERENCES Classroom(Id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS TeacherSubjects (
                    TeacherId INTEGER NOT NULL,
                    SubjectId INTEGER NOT NULL,
                    PRIMARY KEY (TeacherId, SubjectId),
                    FOREIGN KEY (SubjectId) REFERENCES Subject(Id) ON DELETE CASCADE,
                    FOREIGN KEY (TeacherId) REFERENCES Teacher(Id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS TeacherClassrooms (
                    TeacherId INTEGER NOT NULL,
                    ClassroomId INTEGER NOT NULL,
                    PRIMARY KEY (TeacherId, ClassroomId),
                    FOREIGN KEY (ClassroomId) REFERENCES Classroom(Id) ON DELETE CASCADE,
                    FOREIGN KEY (TeacherId) REFERENCES Teacher(Id) ON DELETE CASCADE
                );"
            );
        }
    }
}