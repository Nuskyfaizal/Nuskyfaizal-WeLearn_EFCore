﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ClassroomProject.Models
{
    public class Teacher
    {
        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }      

        public string ContactNo { get; set; }

        public string EmailAddress { get; set; }

        public ICollection<TeacherSubject> Subjects { get; set; } = new List<TeacherSubject>();
        public ICollection<TeacherClassroom> Classrooms { get; set; } = new List<TeacherClassroom>();
    }
}
