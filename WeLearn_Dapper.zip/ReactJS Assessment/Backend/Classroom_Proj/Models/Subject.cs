﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ClassroomProject.Models
{
    public class Subject
    {
        public int Id { get; set; }

        public string SubjectName { get; set; }

        public ICollection<TeacherSubject> Teachers { get; set; }
    }
}
