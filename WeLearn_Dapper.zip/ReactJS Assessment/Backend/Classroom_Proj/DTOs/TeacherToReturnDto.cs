namespace ClassroomProject.DTOs
{
    public class TeacherToReturnDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }  
    }
}