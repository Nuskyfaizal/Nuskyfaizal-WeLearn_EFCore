import React from "react";
import { Controller } from "react-hook-form";

export default function Dropdown({ control, name, classroomList }) {
  return (
    <div className="form-group mt-4 text-left">
      <Controller
        name={name}
        control={control}
        defaultValue="" 
        render={({ field }) => (
          <select className="form-control" {...field}>
            <option value="">Select a classroom</option>
            {classroomList.map((classroom) => (
              <option key={classroom.id} value={classroom.id}>{classroom.classroomName}</option>
            ))}
          </select>
        )}
      />
    </div>
  );
}