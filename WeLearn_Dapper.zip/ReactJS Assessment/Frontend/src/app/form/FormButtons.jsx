import React from "react";
import { Button } from "reactstrap";
import { useForm } from "react-hook-form";

export default function FormButtons({ isValid, name }) {
  const { reset } = useForm();

  const doReset = () => {
    reset();
  };

  return (
    <div className="form-group d-flex justify-content-between mt-3">
      <div>
        <Button onClick={doReset} color="warning" style={{ width: "150px" }}>
          Reset
        </Button>
      </div>
      <div>
        <Button disabled={!isValid} color="primary" style={{ width: "150px" }}>
          Save
        </Button>
      </div>
    </div>
  );
}
