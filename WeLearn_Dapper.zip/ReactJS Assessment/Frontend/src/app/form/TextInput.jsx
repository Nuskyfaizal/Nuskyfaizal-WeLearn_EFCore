import React from "react";
import { Controller } from "react-hook-form";
import { Container, Input } from "reactstrap";

export default function TextInput({ label, name, control, type, errorM, isdisabled }) {

  return (
    <Container>
      <div className="form-group row mt-4">
        <Controller
          name={name}
          defaultValue=""
          control={control}
          rules={{
            validate: (value) => {
              if (!value) {
                return errorM || 'Field is required';
              }
              return true;
            },
          }}
          render={({ field, fieldState }) => (
            <>
              <Input {...field} type={type} placeholder={label} disabled={isdisabled} />
              {fieldState.invalid && (
                <span style={{textAlign: "left", color: "red" }}>{errorM}</span>
              )}
            </>
          )}
        />
      </div>
    </Container>
  );
}
