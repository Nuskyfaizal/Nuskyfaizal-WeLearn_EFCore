import React from "react";
import CommonTable from "./CommonTable";
import { Col } from "reactstrap";
import Heading from "./Heading";

export default function CommonView({ name, tableData }) {
  return (
    <>
     <Col xs="12" className="left-box">
      <div className="d-flex align-items-center justify-content-center"></div>
      <Heading title={name} />
      {tableData.length > 0 ? (
        <div>
          <CommonTable data={tableData} name={name} />
        </div>
      ) : (
        <div className="text-center mt-5">
          <h3>
            OOPs no {name} data to show, please add {name}{" "}
            details{" "}
          </h3>
        </div>
      )}
      </Col>
    </>
  );
}
