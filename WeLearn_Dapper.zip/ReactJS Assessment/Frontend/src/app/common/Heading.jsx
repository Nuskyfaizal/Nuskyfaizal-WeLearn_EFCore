import React from 'react'

export default function Heading({title}) {
  return (
    <h5 style={{color: 'white', textAlign: 'left', backgroundColor: 'green' }}>{title} Details</h5>
  )
}
