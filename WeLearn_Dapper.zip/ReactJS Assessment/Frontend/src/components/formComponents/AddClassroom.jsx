import React from "react";
import TextInput from "../../app/form/TextInput";
import { useForm } from "react-hook-form";
import FormButtons from "../../app/form/FormButtons";
import Heading from "../../app/common/Heading";
import { useDispatch } from "react-redux";
import { createClassroom } from "../../store/classroomDataSlice";
import { Col } from "reactstrap";
import "../allocationComponent/TeacherAllocation.scss"

export default function AddClassroom() {
  const {
    control,
    handleSubmit,
    formState: { isValid },
  } = useForm({
    mode: "onTouched",
  });

  const dispatch = useDispatch();

  async function onSubmit(data) {
    console.log(data);
    dispatch(createClassroom(data));
  }

  return (
    <Col xs="12" className="left-box">
      <div className="d-flex align-items-center justify-content-center"></div>
      <form className="text-center" onSubmit={handleSubmit(onSubmit)}>
        <Heading title="aAdd Classroom" />

        <TextInput
          label="Classroom Name"
          name="classRoomName"
          control={control}
          errorM={"Classroom Name is required"}
        />

        <FormButtons name="classroom" isValid={isValid} />
      </form>
    </Col>
  );
}
