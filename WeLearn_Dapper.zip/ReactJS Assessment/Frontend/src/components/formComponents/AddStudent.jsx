import React, { useEffect, useState } from "react";
import TextInput from "../../app/form/TextInput";
import { useForm } from "react-hook-form";
import FormButtons from "../../app/form/FormButtons";
import Heading from "../../app/common/Heading";
import Dropdown from "../../app/form/Dropdown";
import { useDispatch, useSelector } from "react-redux";
import "../allocationComponent/TeacherAllocation.scss"
import {
  addStudent,
  getStudent,
  updateStudent,
} from "../../store/studentDataSlice";
import { getClassrooms } from "../../store/classroomDataSlice";
import { toast } from "react-toastify";
import { useParams } from "react-router-dom";
import { Col, Row } from "reactstrap";

export default function AddStudent() {
  const {
    control,
    handleSubmit,
    reset,
    formState: { isValid },
  } = useForm({ mode: "onTouched" });
  const dispatch = useDispatch();
  const { classroomList } = useSelector((state) => state.classroomReducer);
  const { student } = useSelector((state) => state.studentsReducer);
  const { id } = useParams();
  const [editDisabled, setEditDisabled] = useState(false);

  function getClassroom() {
    dispatch(getClassrooms()).then((data) => {
      if (data.meta.requestStatus === "rejected") {
        toast.error("Please add classroom before creating a student");
      }
    });
  }

  function onSubmit(data) {  
    try {
      if (id) {
        data.classroomId = parseInt(data.classroomId, 10);
        dispatch(updateStudent({ id: id, updatedStudent: data }))
      } else {
        data.classroomId = parseInt(data.classroomId, 10);
        dispatch(addStudent(data))
      }
    } catch (error) {
      toast.error(error.message);
    }
  }

  useEffect(() => {
    if (id) {
      dispatch(getStudent(id)).then((res) => {
        if (res.meta.requestStatus === "fulfilled") {
          const dateOfBirth =
            student.dateOfBirth === undefined || null
              ? ""
              : student.dateOfBirth.split("T")[0];
          const {
            firstName,
            lastName,
            contactPerson,
            contactNo,
            emailAddress,
            classroomId,
          } = student;
          reset({
            firstName,
            lastName,
            contactPerson,
            contactNo,
            emailAddress,
            dateOfBirth,
            classroomId,
          });
          setEditDisabled(true);
          getClassroom();
        }
      });
    } else {
      getClassroom();
    }
  }, [student.firstName]);

  return (
    <Col xs="12" className="left-box">
      <div className="d-flex align-items-center justify-content-center"></div>
      <form className="text-center" onSubmit={handleSubmit(onSubmit)}>
        <Heading title="Add Student" />

        <Row>
          <Col md="6">
            <TextInput
              isdisabled={editDisabled}
              label="First Name"
              name="firstName"
              control={control}
              errorM={"First Name is required"}
            />
          </Col>
          <Col md="6">
            <TextInput
              isdisabled={editDisabled}
              label="Last Name"
              name="lastName"
              control={control}
              errorM={"Last Name is required"}
            />
          </Col>
        </Row>

        <Row>
          <Col md="6">
            <TextInput
              label="Contact Person"
              name="contactPerson"
              control={control}
              errorM={"Contact Person is required"}
            />
          </Col>
          <Col md="6">
            <TextInput
              label="Contact Number"
              type="number"
              name="contactNo"
              control={control}
              errorM={"Contact Number is required"}
            />
          </Col>
        </Row>
        <Row>
          <Col md="6">
            <TextInput
              label="Email Address"
              name="emailAddress"
              control={control}
              errorM={"Email Address is required"}
            />
          </Col>
          <Col md="6">
            <TextInput
              isdisabled={editDisabled}
              label="Date of Birth (YYYY-MM-DD)"
              type="date"
              name="dateOfBirth"
              control={control}
              errorM={"DOB is required"}
            />
          </Col>
        </Row>

        <Row>
          <Col md="6">
            <Dropdown
              isdisabled={editDisabled}
              type="select"
              control={control}
              name="classroomId"
              classroomList={classroomList}
            />
          </Col>
        </Row>
        <Col md="6">
          <FormButtons name="student" isValid={isValid} />
        </Col>
      </form>
    </Col>
  );
}
