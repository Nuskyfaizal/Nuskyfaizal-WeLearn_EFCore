import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Col, Container, Row, Table } from "reactstrap";
import { resetStudentReportData } from "../../store/studentDataSlice";

export default function TeacherAndSubject() {
  const dispatch = useDispatch();
  const { studentReportData } = useSelector((state) => state.studentsReducer);
  const subjectTeachers = studentReportData.subjectTeachers;

  useEffect(() => {
    return() => {
      dispatch(resetStudentReportData())
    }
  }, [dispatch])

  return (
    <Container hidden={subjectTeachers.length === 0}>
      <Row>
        <Col xs="12" className="right-box">
          <div className="box-name">Teacher & Subject Details</div>
          <div className="grid">
            <Table bordered>
              <thead>
                <tr className="table-secondary">
                  <th>Subject</th>
                  <th>Teacher</th>
                </tr>
              </thead>
              <tbody className="table-secondary">
                {subjectTeachers.map((subjectTeacher, index) => (
                  <tr key={index}>
                    <td>{subjectTeacher.teacherName}</td>
                    <td>{subjectTeacher.subjectName}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </Col>
      </Row>
    </Container>
  );
}
