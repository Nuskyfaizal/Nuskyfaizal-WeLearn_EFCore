import React, { useEffect, useState } from "react";
import {Container,Row,Col,Label,Button,Input,Table} from "reactstrap";
import "./TeacherAllocation.scss";
import TeacherDetailsDropdown from "./TeacherDetailsDropdown";
import { useLocation, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from "react-redux";
import { getClassrooms } from "../../store/classroomDataSlice";

export default function TeacherClassroom() {
 const location = useLocation();
 const navigate = useNavigate();
 const dispatch = useDispatch();
 const { classroomList } = useSelector(state => state.classroomReducer);
 const { allocatedClassroomList } = useSelector((state) => state.teacherReducer);
 const [isTeacherSelected, setIsTeacherSelected] = useState(false);
 const [isClassroomSelected, setIsClassroomSelected] = useState(false);
 const [allocatedClassrooms, setAllocatedClassrooms] = useState([]);
 const [selectedClassroomId, setSelectedClassroomId] = useState();

 function classroomSelectToggle(e){
  if(e.target.value !== "")
  setSelectedClassroomId(e.target.value)
  setIsClassroomSelected(true)
 }

 function allocateClassroom() {
  const classroom = classroomList.find(classroom => classroom.id == selectedClassroomId);
  if(classroom && !allocatedClassrooms.some(allocated => allocated.id === classroom.id)){
    setAllocatedClassrooms([...allocatedClassrooms, {id: classroom.id, classroomName: classroom.classroomName}])
  }
 }

 function onDeallocate(id){
  setAllocatedClassrooms(allocatedClassrooms.filter(classroom => classroom.id !== id))
 }

  useEffect(() => {
    if(isTeacherSelected){
      setAllocatedClassrooms(allocatedClassroomList)
    }

    dispatch(getClassrooms())
  },[dispatch, isTeacherSelected, allocatedClassroomList])

  return (
    <Container>
      <div className="d-flex justify-content-end mb-4">
        <Button color="primary" className="ml-auto" onClick={() => navigate('/manageSubjects')}>
          {location.pathname === '/manageSubjects' ? 'Manage Classrooms' : 'Manage Subjects'}       
        </Button>
      </div>
      <Row>
        <TeacherDetailsDropdown setIsTeacherSelected={setIsTeacherSelected} allocatedSubjectOrClassroom={allocatedClassrooms} />

          <Col xs="12" className="right-box">
            <div className="box-name">Allocate Classrooms</div>
              <div className="d-flex justify-content align-items-center">
                <Label className="p-4 mr-1">Classrooms</Label>
                <Input
                  onChange={(e) => classroomSelectToggle(e)}
                  value={selectedClassroomId}
                  type="select"
                  style={{ width: "200px", height: "38px", marginRight: "30px" }}
                >
                  <option value=''>Select a Classroom</option>
                  {classroomList.map((classroom) => (
                    <option key={classroom.id} value={classroom.id}>{classroom.classroomName}</option>
                  ))}
                </Input>
                <Button color="primary" disabled={!isClassroomSelected && !isTeacherSelected} onClick={allocateClassroom}>
                  Allocate
                </Button>
              </div>
         
            {allocatedClassrooms.length >= 1 && (
              <div className="grid">
                <Table bordered>
              <thead>
                <tr className="table-secondary">
                  <th>Classrooms</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody className="table-secondary">
                {allocatedClassrooms.map((classroom, index) => (
                  <tr key={index}>
                    <td>{classroom.classroomName}</td>
                    <td width={3}>
                      <Button color="primary" onClick={() => onDeallocate(classroom.id)}>Deallocate</Button>
                    </td>
                  </tr>
                ))} 
              </tbody>
            </Table>
          </div>
            )}
            
        </Col>
      </Row>
    </Container>
  );
}
