import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button, Col, Input, Label } from "reactstrap";
import { allocateClassroom, allocateSubject, getAllocatedClassrooms, getAllocatedSubjects, getTeacherData } from "../../store/teacherDataSlice";
import { useLocation, useNavigate } from 'react-router-dom';

export default function TeacherDetailsDropdown({setIsTeacherSelected, allocatedSubjectOrClassroom}) {
  const { teachersList } = useSelector((state) => state.teacherReducer);
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const [selectedTeacherId, setSelectedTeacherId] = useState('');

  function teacherToggle(e) {
    if(e.target.value !== ""){
        setSelectedTeacherId(e.target.value)
        setIsTeacherSelected(true)
      if(location.pathname === '/manageSubjects'){  
        dispatch(getAllocatedSubjects(e.target.value))      
      } else{
        dispatch(getAllocatedClassrooms(e.target.value))
      }
    }   
  }

  function saveTeacherAllocation(id, subjectOrClass ){
    if(location.pathname === '/manageSubjects'){
      dispatch(allocateSubject({id: id, allocatedSubject: subjectOrClass })).then(() => {
        navigate('/teacher')
      })
    } else(
      dispatch(allocateClassroom({id: id, allocatedClassroom: subjectOrClass})).then(() => {
        navigate('/teacher')
      })
    )   
  }

  useEffect(() => {
    dispatch(getTeacherData())
  },[dispatch, selectedTeacherId])

  return (
    <Col xs="12" className="left-box">
      <div className="box-name">Teacher Details</div>
      <div className="d-flex justify-content align-items-center">
        <Label className="p-4 mr-1">Teacher</Label>
        <Input
          onChange={(e) => teacherToggle(e)}
          value={selectedTeacherId}
          type="select"
          style={{ width: "200px", height: "38px", marginRight: "30px" }}
        >
          <option value="">Select a Teacher</option>
          {teachersList.map((teacher) => (
            <option key={teacher.id} value={teacher.id}>{teacher.firstName}</option>
          ))}
        </Input>
        <Button 
          color="primary" 
          className="pr-4" 
          disabled={allocatedSubjectOrClassroom.length == 0}
          onClick={() => saveTeacherAllocation(selectedTeacherId,allocatedSubjectOrClassroom )}
        >
          Save
        </Button>
      </div>
    </Col>
  );
}
