import React from "react";
import { Container, Row, Col } from "reactstrap";
import { PiStudentBold } from "react-icons/pi";
import { GiTeacher } from "react-icons/gi";
import { SiGoogleclassroom } from "react-icons/si";
import { IoBookSharp } from "react-icons/io5";
import { Link } from "react-router-dom";

export default function HomePage() {
  return (
    <>
      <Container className="text-center">
        <Row className="align-items-center">
          <Col>
            <h1 className="bg-light-green">Welcome to WeLearn Management</h1>
          </Col>
        </Row>
        <Row className="justify-content-center mt-4">
          <Col sm={6} md={3} className="bg-light-green p-3">
            <PiStudentBold size={150} />
            <div className="p-3">
              <Link to='/student' className="btn btn-success">Manage Students</Link>
            </div>
          </Col>
          <Col sm={6} md={3} className="bg-light-green p-3">
            <GiTeacher size={150} />
            <div className="p-3">
              <Link to='/teacher' className="btn btn-success">Manage Teachers</Link>
            </div>
          </Col>
        </Row>
        <Row className="justify-content-center mt-4">
          <Col sm={6} md={3} className="bg-light-green p-3">
            <SiGoogleclassroom size={150} />
            <div className="p-3">
              <Link to='/classroom' className="btn btn-success">Manage Classrooms</Link>
            </div>
          </Col>
          <Col sm={6} md={3} className="bg-light-blue p-3">
            <IoBookSharp size={150} />
            <div className="p-3">
              <Link to='/subject' className="btn btn-success">Manage Subjects</Link>
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
}
