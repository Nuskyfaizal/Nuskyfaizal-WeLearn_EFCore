import React from "react";
import { Navbar, Nav, NavItem, NavLink, NavbarBrand } from "reactstrap";
import {  useNavigate } from 'react-router';

export default function NavBar() {
  const navigate = useNavigate();

  const doReturn = () => {
    navigate('/')
  }

  return (
    <div>
      <Navbar color="success" dark expand="md">
        <NavbarBrand className="mr-2" href="/">WeLearn</NavbarBrand>
        <Nav className="ml-auto" navbar>
          <NavItem>
            <NavLink onClick={doReturn} className="mr-auto cursor-pointer">Home</NavLink>
          </NavItem>
          <NavItem>
            <NavLink href="#">Login</NavLink>
          </NavItem>
        </Nav>
      </Navbar>
    </div>
  );
}
