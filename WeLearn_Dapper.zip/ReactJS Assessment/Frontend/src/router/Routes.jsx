import App from "../App";
import { createBrowserRouter } from "react-router-dom";
import Student from "../components/Student";
import Teacher from "../components/Teacher";
import Subject from "../components/Subject";
import Classroom from "../components/Classroom";

export const routes = [
    {
        path: '/',
        element: <App />,
        children:[
            {path: 'student', element: <Student />},
            {path: 'teacher', element: <Teacher />},
            {path: 'subject', element: <Subject />},
            {path: 'classroom', element: <Classroom />},
        ]
    }
]

export const router = createBrowserRouter(routes);