import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import agent from "../api/agent";
import { toast } from "react-toastify";
import { router } from "../router/Routes";

const initialState = {
  subjectList: [],
};

const subjectDataSlice = createSlice({
  name: "subjectData",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getSubjects.fulfilled, (state, action) => {
        state.subjectList = action.payload;
      })
  },
});

export default subjectDataSlice.reducer;

export const getSubjects = createAsyncThunk(
  "subjectData/getSubjects",
  async () => {
    const subjectList = await agent.Subjects.list();
    return subjectList;
  }
);

export const createSubjects = createAsyncThunk(
  "subjectData/add",
  async (createSubject, { rejectWithValue }) => {
    try {
      await agent.Subjects.create(createSubject);
      toast.success("Subject Created successfully");
      router.navigate("/subject");
      return createSubject;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const deleteSubject = createAsyncThunk(
  "subjectData/delete",
  async (id, { rejectWithValue }) => {
    try {
      await agent.Subjects.del(id);
      toast.success("Subject deleted successfully");
      return "ok";
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);
