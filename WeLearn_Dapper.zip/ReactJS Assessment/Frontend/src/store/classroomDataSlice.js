import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import agent from "../api/agent";
import { toast } from "react-toastify";
import { router } from "../router/Routes";

const initialState = {
  classroomList: [],
};

const classroomDataSlice = createSlice({
  name: "classroomData",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getClassrooms.fulfilled, (state, action) => {
        state.classroomList = action.payload;
      })
  },
});

export default classroomDataSlice.reducer;

export const getClassrooms = createAsyncThunk(
  "classroomData/getClassrooms",
  async () => {
    const classroomList = await agent.Classrooms.list();
    return classroomList;
  }
);

export const createClassroom = createAsyncThunk(
  "classroomData/add",
  async (createClassroom, { rejectWithValue }) => {
    try {
      await agent.Classrooms.create(createClassroom);
      toast.success("Classroom Created successfully");
      router.navigate("/classroom");
      return createClassroom;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const deleteClassroom = createAsyncThunk(
  "classroomData/delete",
  async (id, { rejectWithValue }) => {
    try {
      await agent.Classrooms.del(id);
      toast.success("Classroom deleted successfully");
        return 'ok'
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);
