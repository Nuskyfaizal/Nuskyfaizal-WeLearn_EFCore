import { configureStore } from "@reduxjs/toolkit";
import studentDataSlice from "./studentDataSlice";
import classroomDataSlice from "./classroomDataSlice";
import subjectDataSlice from "./subjectDataSlice";
import teacherDataSlice from "./teacherDataSlice";

const store = configureStore({
  reducer: {
    studentsReducer: studentDataSlice,
    classroomReducer: classroomDataSlice,
    subjectReducer: subjectDataSlice,
    teacherReducer: teacherDataSlice
  },
});

export default store;
