import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import agent from "../api/agent";
import { router } from "../router/Routes";
import { toast } from "react-toastify";

const initialState = {
  studentsList: [],
  student: [],
  studentReportData: {
    classroom: "",
    contactPerson: "",
    contactNo: "",
    emailAddress:"",
    dateOfBirth: "",
    subjectTeachers: []
  }
};

const studentDataSlice = createSlice({
  name: "studentData",
  initialState,
  reducers: {
    resetStudentReportData: (state) => {
      state.studentReportData = initialState.studentReportData;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(getStudentsData.fulfilled, (state, action) => {
        state.studentsList = action.payload;
      })
      .addCase(getStudent.fulfilled, (state, action) => {
        state.student = action.payload;
      })
      .addCase(getStudentDataForReport.fulfilled,( state, action) => {
        state.studentReportData = action.payload;
      })
  },
});

export const { resetStudentReportData } = studentDataSlice.actions;
export default studentDataSlice.reducer;

export const getStudent = createAsyncThunk(
  "studentData/getStudent",
  async (id) => {
    const student = await agent.Students.detail(id);
    return student;
  }
);

export const getStudentsData = createAsyncThunk("studentData/getStudents",
  async () => {
    const studentList = await agent.Students.list();
    return studentList;
  }
);

export const addStudent = createAsyncThunk("studentData/add",
  async (createStudentData, { rejectWithValue }) => {
    try {
      await agent.Students.create(createStudentData);
      toast.success("Student Created successfully");
      router.navigate("/student");
      return createStudentData;
    } catch (error) {
      toast.error("Please enter valid details");
      return rejectWithValue(error);
    }
  }
);

export const deleteStudent = createAsyncThunk(
  "studentData/delete",
  async (id, { rejectWithValue }) => {
    try {
      await agent.Students.del(id);
      toast.success("Student data deleted successfully");
        return 'ok'
    } catch (error) {
      toast.error("Error while deleting Student data");
      return rejectWithValue(error);
    }
  }
);

export const updateStudent = createAsyncThunk(
  "studentData/update",
  async ({id, updatedStudent}) => {
    try {
      await agent.Students.edit(id, updatedStudent);
      toast.success("Student information updated successfully");
      return "ok";
    } catch (error) {
      toast.error("Error while updating student information");
      return 'failed';
    }
  }
);

export const getStudentDataForReport = createAsyncThunk(
  "studentData/getStudentDataForReport",
  async (id) => {
    const studentReportData = await agent.Students.reportData(id);
    return studentReportData ; 
  }
);
