using System.Collections.Generic;
using System.Threading.Tasks;
using API.Models;

namespace API.Repository
{
    public interface IEmployeeRepo
    {
        Task<bool> AddEmployee(Employee employee);
        Task<IEnumerable<Employee>> GetEmployees();
        Task<Employee> GetEmployee(int id);
        Task<bool> DeleteEmployee(int id);
        Task<bool> EditEmployee(Employee employeeForEdit, int id);
    }
}