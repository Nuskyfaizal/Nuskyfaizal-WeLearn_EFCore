using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using API.Database;
using API.Helpers;
using API.Models;
using Dapper;

namespace API.Repository
{
    public class EmployeeRepo : IEmployeeRepo
    {
        private readonly IDbConnectionFactory _connectionFactory;
        private readonly IUnitOfWork _unitOfWork;

        public EmployeeRepo(IDbConnectionFactory connectionFactory, IUnitOfWork unitOfWork)
        {
            _connectionFactory = connectionFactory;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> AddEmployee(Employee employee)
        {
            try
            {
                using var connection = await _connectionFactory.CreateConnectionAsync();

                var result = await connection.ExecuteAsync(
                    @"INSERT INTO employee (empNo, empName, empAddressLine1, empAddressLine2, empAddressLine3,
                empDateOfJoin, empStatus, empImage) 
                VALUES (@EmpNo, @EmpName, @EmpAddressLine1, @EmpAddressLine2, @EmpAddressLine3, @EmpDateOfJoin,
                @EmpStatus, @EmpImage)",
                    employee);

                return result > 0;
            } catch(Exception ex)
            {
                throw;
            }           
        }

        public async Task<bool> DeleteEmployee(int id)
        {
            var isEmployeeAvailable = await _unitOfWork.GetAsync<Employee>(id);

            if (isEmployeeAvailable == null)
                return false;

            var result = await _unitOfWork.DeleteAsync<Employee>(id);

            if (result) return true;

            return false;
        }

        public async Task<bool> EditEmployee(Employee employeeForEdit, int id)
        {
            try
            {
                var isEmployeeAvailable = await _unitOfWork.GetAsync<Employee>(id);

                if (isEmployeeAvailable == null)
                    return false;

                using var connection = await _connectionFactory.CreateConnectionAsync();

                var query = @"UPDATE employee SET 
                    empName = @EmpName,
                    empAddressLine1 = @EmpAddressLine1,
                    empAddressLine2 = @EmpAddressLine2,
                    empAddressLine3 = @EmpAddressLine3,
                    empDateOfJoin = @EmpDateOfJoin,
                    empStatus = @EmpStatus,
                    empImage = @EmpImage
                    WHERE 
                    Id = @Id";

                var parameters = new
                {
                    Id = id,
                    employeeForEdit.EmpName,
                    employeeForEdit.EmpAddressLine1,
                    employeeForEdit.EmpAddressLine2,
                    employeeForEdit.EmpAddressLine3,
                    employeeForEdit.EmpDateOfJoin,
                    employeeForEdit.EmpStatus,
                    employeeForEdit.EmpImage
                };

                var result = await connection.ExecuteAsync(query, parameters);

                return result > 0;
            } catch(Exception ex)
            {
                throw;
            }
            
        }

        public async Task<Employee> GetEmployee(int id)
        {
            return await _unitOfWork.GetAsync<Employee>(id);
        }

        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            return await _unitOfWork.GetAllAsync<Employee>();
        }
    }
}