﻿using API.Models;
using API.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeesController : Controller
    {
        private readonly IEmployeeRepo employeeRepo;

        public EmployeesController(IEmployeeRepo _employeeRepo)
        {
            employeeRepo = _employeeRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetEmployeeList()
        {
            var employees = await employeeRepo.GetEmployees();

            if (employees.Count() == 0) return NotFound("No data to show");

            return Ok(employees);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetEmployeeDetail(int id)
        {
            var employee = await employeeRepo.GetEmployee(id);

            if (employee == null) return NotFound("No data to show");

            return Ok(employee);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEmployee([FromBody] Employee employee)
        {
            var isemployeeCreated = await employeeRepo.AddEmployee(employee);

            if (!isemployeeCreated) return BadRequest("Failed to add employee");

            return Ok("employee created successfully");
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteEmployee(int id)
        {
            var deleteEmployee = await employeeRepo.DeleteEmployee(id);

            if (!deleteEmployee) return BadRequest();

            return Ok("Employee deleted successfully");
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> EditEmployee([FromBody] Employee employeeForEdit, int id)
        {
            var editEmployee = await employeeRepo.EditEmployee(employeeForEdit, id);

            if (!editEmployee) return BadRequest("Failed to edit employee");

            return Ok("Employee edited successfully");
        }
    }
}
