using API.Models;
using FluentValidation;

namespace API.Validations
{
    public class EmployeeRequestValidator: AbstractValidator<Employee>
    {
        public EmployeeRequestValidator()
        {
            RuleFor(x => x.EmpName).NotEmpty();
            RuleFor(x => x.EmpNo).NotEmpty();
            RuleFor(x => x.EmpAddressLine1).NotEmpty();
            RuleFor(x => x.EmpAddressLine1).NotEmpty();
            RuleFor(x => x.EmpAddressLine1).NotEmpty();
            RuleFor(x => x.EmpStatus).NotEmpty();
            RuleFor(x => x.EmpImage).NotEmpty();
        }
    }   
}