using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Helpers
{
    public interface IUnitOfWork
    {
        Task<T> GetAsync<T>(int id);

        Task<IEnumerable<T>> GetAllAsync<T>();

        Task<bool> DeleteAsync<T>(int id);
    }
}