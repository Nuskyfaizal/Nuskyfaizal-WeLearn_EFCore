using API.Database;
using Dapper;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Helpers
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IDbConnectionFactory _connectionFactory;

        public UnitOfWork(IDbConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<bool> DeleteAsync<T>(int id)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            var result = await connection.ExecuteAsync(
                $"DELETE FROM {typeof(T).Name} WHERE Id = @Id", new { Id = id });

            return result > 0;
        }

        public async Task<IEnumerable<T>> GetAllAsync<T>()
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            return await connection.QueryAsync<T>("SELECT * FROM " + typeof(T).Name);
        }

        public async Task<T> GetAsync<T>(int id)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            return await connection.QuerySingleOrDefaultAsync<T>(
                $"SELECT * FROM {typeof(T).Name} WHERE Id = @Id", new { Id = id });
        }
    }
}