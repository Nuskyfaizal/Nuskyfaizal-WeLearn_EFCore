using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace API.Helpers
{
    public interface IUnitOfWork
    {
        Task<T> GetAsync<T>(int id);

        Task<IEnumerable<T>> GetAllAsync<T>();

        Task<bool> DeleteAsync<T>(int id);   

        Task<IEnumerable<T>> QueryBySP<T>(string storedProcedureName, Dictionary<string, Tuple<string, DbType, ParameterDirection>> parameters);
    
        Task<int> ExecuteSP(string storedProcedureName, Dictionary<string, Tuple<string, DbType, ParameterDirection>> parameters);
    }
}