using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Validations
{
    public class EmployeeRequestValidator: AbstractValidator<Employee>
    {
        public EmployeeRequestValidator()
        {
            // RuleFor(x => x.FirstName).NotEmpty();
            // RuleFor(x => x.LastName).NotEmpty();
            // RuleFor(x => x.ContactPerson).NotEmpty();
            // RuleFor(x => x.ContactNo).NotEmpty().Length(10).WithMessage("Contact number must be 10 digits.");;
            // RuleFor(x => x.EmailAddress).NotEmpty().EmailAddress();
            // RuleFor(x => x.DateOfBirth)
            //     .NotEmpty()
            //     .LessThan(DateTime.Now)
            //     .WithMessage("Date of birth cannot be in the future");
        }
    }   
}