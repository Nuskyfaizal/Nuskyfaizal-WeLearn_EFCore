using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Models
{
    public class Employee
    {
        public int Id { get; set; }

        public string EmployeeNumber { get; set; }

        public string Name { get; set; }

        public string AddressLine1 { get; set; }
  
        public string AddressLine2 { get; set; }

        public string AddressLine3 { get; set; }

        public DateTime DateOfJoin { get; set; }

        public bool Status { get; set; }

        public string Image { get; set; }
    }
}