using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Database
{
    public class DbConnectionFactory
    {
        public interface IDbConnectionFactory
        {
            public Task<IDbConnection> CreateConnectionAsync();
        }

        public class SqlConnectionFactory : IDbConnectionFactory
        {
            private readonly string connectionString;

            public SqlConnectionFactory(string connectionString)
            {
                this.connectionString = connectionString;
            }

            public async Task<IDbConnection> CreateConnectionAsync()
            {
                // var connection = new NpgsqlConnection(connectionString);
                // await connection.OpenAsync();
                // return connection;
            }
        }
    }
}